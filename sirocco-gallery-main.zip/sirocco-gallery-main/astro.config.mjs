import { defineConfig } from 'astro/config';
import vercel from '@astrojs/vercel';

export default defineConfig({
  site: 'https://sirocco.gallery',
  output: 'static',
  adapter: vercel(),
  trailingSlash: 'never',
  // Astro's blanket Origin/Host check 403s the request form behind Vercel's
  // www/apex proxy. The /api/request route enforces its own origin allowlist.
  security: { checkOrigin: false },
});
