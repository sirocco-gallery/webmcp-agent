# sirocco — demo video guide

Internal. For recording the visibility/proof clip. Written to be followable by
someone who doesn't enjoy video: **screen recordings only, text captions instead
of a voiceover, minimal editing.** No talking head, no script to read aloud.

## The goal (one sentence)
Show that sirocco is a *real, operational* WebMCP surface where an autonomous
agent enforces design-intent — drift named, build corrected, tokens honored —
and that the tools are genuinely registered, not a mock.

## The dead-simple approach
Three short screen recordings, stitched in order, with a few text captions over
them. Target **45–75 seconds**. That's the whole thing. If you do only Clips 1–2,
you still have a strong artifact.

## Tools (pick what you have)
- **Record:** macOS — QuickTime (File → New Screen Recording) or `Shift-Cmd-5`.
  Windows — Xbox Game Bar (`Win-G`) or OBS. Browser tab only is fine.
- **Edit/caption:** CapCut (free, easiest), iMovie, or Clipchamp. You only need:
  trim clips, place them in order, drop text on top. Nothing fancier.

## Settings (set once)
- Record at **1080p**, 30fps. Record a single browser window, not the full desktop.
- Browser at a clean zoom (⌘0). Hide bookmarks bar. Close other tabs.
- Move your mouse deliberately and slowly — fast cursor jumps read as nervous.
- No audio needed. (If you want music, add one low royalty-free track in the editor.)

## The shot list

### Clip 1 — the floor (the wow) · ~12s
1. Open **/session** (the floor). Let it autoplay once — the transcript fills, the
   panel **morphs drift → clean**, ends on "clean · honors …".
2. Click another palette chip (e.g. **brass hour**) — let it run again, themed.
3. Stop recording after the second clean.
- **Caption (overlay):** "An agent holds each design system to its own tokens."
- **Caption (lower third, later in the clip):** "the checks are real."

### Clip 2 — run it for real (the proof of "real") · ~15–20s
1. On the floor, click **"run it for real →"**. Wait through "a live model is
   working…" (the ~4–6s is fine; you can speed this section 1.5× in the editor).
2. Show the live transcript: it drafts, **check_design_drift names the drift**
   (`found … → expected color.… #hex`), it adopts the exact tokens, **re-checks
   clean**. Panel snaps to honored.
- **Caption:** "Now for real — a live model, deciding for itself."
- **Caption (over the drift lines):** "It doesn't get the tokens. The steward
  hands back the exact ones. It adopts them and re-checks."

### Clip 3 — the WebMCP proof (these tools are real) · ~15s
Two honest ways; do the first, add the second if you have Canary set up.
1. **Anywhere works:** point at the **`webmcp · 5 tools live`** badge (bottom-right),
   click it → lands on **/lab**. Show the status line ("…registered on
   document.modelContext"). Click **Run** on `check_design_drift` (it's prefilled)
   → real JSON drift appears. Run `normalize_tokens` too.
   - **Caption:** "Not a mock — the exact tools sirocco registers for agents. Run them yourself."
2. **(Optional, the literal transport shot — Canary):** in Chrome Canary with your
   flags on, open the **Model Context Tool Inspector**, show the 5 tools listed off
   `document.modelContext`, and invoke `check_design_drift` from there → real result.
   - **Caption:** "And a real in-browser agent calls them over WebMCP."

### End card · ~3s
- Black (or the homepage) with text:
  **sirocco.gallery** — *a live WebMCP design surface, built for autonomous agents.*

## Assembly (10 minutes in CapCut/iMovie)
1. Drop Clip 1, Clip 2, Clip 3, End card in order on the timeline.
2. Trim dead air at the head/tail of each. Speed up any waiting (Clip 2's model
   call) to ~1.5–2×.
3. Add the captions above as text layers. Keep them short, on screen ~2–3s each,
   bottom third, plain white. Don't over-caption — one idea at a time.
4. Export 1080p MP4.

## If you only do one thing
Record **Clip 2 (run it for real)** cleanly with the two captions. A live model
naming real drift and correcting itself *is* the proof. Everything else is bonus.

## Shot-list cheat (inputs, if you invoke tools by hand in /lab or the Inspector)
- `list_instruments` → `{}`
- `recommend_instrument` → `{"need":"a dark warm dashboard"}`
- `get_instrument` → `{"id":"001"}`
- `check_design_drift` → `{"instrument_id":"001","code":".panel{ color:#ff00ff; border-radius:12px; }"}`
- `normalize_tokens` → paste any messy `:root{ --color-bg:#0e0e10; --radius-md:8px; }`

## Notes
- Honesty line to keep in mind: the floor's **replay** is the loop *scripted from
  real checks*; **run it for real** is a *live model*; the **tools are genuinely
  registered**. The site says exactly this now, so the video can too without
  hedging.
- Mind the live-run rate cap (a handful per 10 min) while rehearsing takes.
