# sirocco — roadmap & working notes

Internal. **The product is the capability, not the palettes.** sirocco is BYO
design-intent enforcement — deterministic check + steward — made portable over
WebMCP/MCP. The palettes are the demonstration substrate (the stage the open
capability runs on), not commercial inventory. Visibility first; the buyer path
(paid BYO) must be real.

## Thesis (the structural shift — read this first)
- **Not a palette-selling product.** The thing of value is the capability: BYO
  intent enforcement, portable across WebMCP (in-browser) and MCP (the IDE /
  coding-agent connector), deterministic check + steward.
- **Two surfaces, one core:**
  - **Open capability surface** — complete, agent-walkable, free, ungated. Runs
    on the **house palette** so an autonomous agent can prove the whole loop end
    to end. This is the reference implementation / visibility flag.
  - **Paid BYO** — the same capability on the user's own tokens. **$150,
    Founder's price, one-time, lifetime**, with a reasonable-use rate cap on
    validation calls.
- **swatchdog vs. sirocco, clean:** swatchdog = the engine (deterministic,
  headless, the commodity validator, frozen-pending-review). sirocco = the open
  capability-demonstration surface + paid BYO (the WebMCP/MCP showcase the engine
  shouldn't itself carry). Engine vs. showcase-with-paid-upgrade. Not a clone.
- **Positioning:** present as a working reference implementation / capability
  surface (authority language), not "a demo." Premium early-adopter framing; the
  price is part of the status signal.

## Principles
- **Never touch the swatchdog connector** while it's under Anthropic connector-
  directory review. Read-only as-is; no new high-volume usage patterns.
- **THE FREEZE LINE (critical):** the open surface's check must **NOT** hit the
  frozen engine at volume. An autonomous agent walking the open path freely would
  be a firehose against the frozen connector. So the open check runs sirocco-side
  / client-side on the **house palette** (tokens are known and public-by-design).
  The paid BYO live-check against the engine waits for unfreeze.
- **No backend vendor names in public artifacts** (copy, code comments, PRs).
  Env vars stay generic (`DATABASE_URL`, etc.).
- **Open the demo, gate the BYO.** The open capability surface is free and
  complete; the paid thing is the capability on *your* tokens (persistence, the
  per-purchase MCP endpoint, the live engine check).

## Shipped
- Canonical token sets for all six house palettes (+ export generator, gitignored to `private/`).
- **Open surface check is freeze-safe (Phase 0).** `src/lib/check.ts` — a pure,
  deterministic drift checker (color + radius), matching the engine's result
  contract `{ ok, violations:[{axis,found,expected,expectedValue}], count }`. Runs
  **client-side** on the serialized house-palette reference tokens in the WebMCP
  `check_design_drift` tool, the in-page steward, and `/studio`. **No path in the
  open surface calls the engine.** `/api/check` (the engine proxy) is kept dormant,
  reserved for the paid path.
- WebMCP provider surface: 5 tools on `document.modelContext` (`list_instruments`, `recommend_instrument`, `get_instrument`, `check_design_drift`, `normalize_tokens`), verified in Canary via the Inspector.
- `/steward` (public explainer), `/mint` (BYO normalizer v1+v2: css vars, json, Tokens Studio, Tailwind, raw-CSS inference). `/studio` retired from nav (dormant + noindex, reserved to become the BYO workbench when BYO lands). Per-instrument **dossiers removed** — the floor (autonomous demo) + `/mint` (BYO) + `/lab` (run the tools by hand) cover everything they did; they read as palette product pages, off-thesis. Surface map is now: floor · steward · mint · lab · request.
- Soft layer (`/api/intent`): intent-based "spirit" judgment via Claude Sonnet 4.6 (structured output), on steward + studio, capped-public rate limit. House palettes only. Needs `ANTHROPIC_API_KEY` (Vercel). No swatchdog.
- **Copy repositioned site-wide to the capability thesis.** Front door (home,
  session) keeps the salon veil; the workshop (steward, studio, mint, request)
  names the capability plainly. Palettes framed as the open demo substrate
  (status `OPEN`, not for sale); the paid path is BYO, **$150 Founder's**. No
  commerce wired — copy only. `$180`/`custody`/"request access"/"private gallery"
  retired.

## Phases (sequence)
- **Phase 0 — Open surface — SHIPPED.** Freeze-safe local check across the whole
  open loop (list → recommend → get → normalize → check). Visibility piece; closes
  the prior latent freeze exposure (the open check used to proxy the engine).
- **The floor (`/session`) — SHIPPED (first-impression surface).** The reference
  implementation as a live stage, not a directory: a scripted-but-real run (engine
  in `src/lib/run.ts`) where an agent drafts a panel, calls the *real*
  `check_design_drift`, reads the named drift, and revises until the build honors
  the tokens — re-checking clean. Split stage: transcript + a preview panel that
  morphs drift→clean. Runs the same loop across all six (palette rail), themed to
  each — i.e. "six systems, one discipline," the BYO-generalization pitch
  dramatized. The driver is scripted now; the stage consumes `Beat`s, so a
  real-agent producer drops into the same shell later (= the shareable artifact).
  No "demo" language; reads as reference implementation. This is the surface the
  autonomous runs get recorded from.
- **Real-agent run — SHIPPED.** "run it for real" on the floor → `/api/run`: a
  live Anthropic tool-use loop (Haiku 4.5, for speed) that drafts a panel from the
  instrument's *intent* (not its exact tokens), calls the real local
  `check_design_drift`, reads the named drift, and corrects from that feedback
  until clean — the steward teaching the agent the system (the product thesis,
  enacted). Emits the same `Beat` stream into the same stage. Freeze-safe (only
  tool is the local checker; no swatchdog). Capped-public: same-origin, 6/10min
  per IP, ≤5 steps. Needs `ANTHROPIC_API_KEY`. Scripted autoplay stays the
  always-on default; the button is the authentic, on-demand run.
- **Phase B — BYO connector — SHIPPED + verified.** `/api/mcp`, a remote MCP
  server (web-standard streamable-HTTP, stateless). Open tier (house instruments)
  proven end-to-end with a real MCP client. BYO tier (Bearer token → the buyer's
  minted set) wired through `lib/store`/`lib/db`. Deterministic + rubric only — no
  LLM, no swatchdog. The MCP twin of the WebMCP surface.
- **Phase A + C — Commerce + persistence — SHIPPED (code-complete, needs keys).**
  Neon schema + queries (`lib/db`), HMAC sessions + magic-link (`lib/auth`), Stripe
  Checkout (`/api/checkout`) + webhook fulfillment (`/api/stripe-webhook`), magic-
  link access (`/api/access`), the gated `/instrument` hub (claim, paste+save
  tokens, issue connector token, copy setup snippet). Untested here — needs
  `DATABASE_URL`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `SESSION_SECRET`.
- **Phase D — Authoritative engine.** Wire the hosted engine into the paid live
  check. Waits on unfreeze.

## BYO — verified, open, and to-do (live as of this session)
- **Verified live:** purchase ($0 via FOUNDER0 100%-off code) → `/instrument`
  claim → entitlement in Neon → "your instrument" page renders. Origin fix landed
  (Vercel `request.url` host = localhost → use `x-forwarded-host`).
- **Config to verify (theirs):**
  - `SESSION_SECRET` MUST be set + strong — sessions/magic-links are HMAC-signed
    with it; unset = empty key = forgeable cookies. Security-critical.
  - Stripe **webhook** delivering 200 to `/api/stripe-webhook` (durable
    fulfillment; redirect-claim is only the happy path).
  - **Resend not sending** the magic-link — likely the sender domain (`REQUEST_SENDER`)
    isn't a verified domain in Resend. Without it, returning buyers can't get back
    in except by re-running checkout. **Fix next session.**
- **Verification gaps:** the connector in **real Claude Code / Cursor** (only
  SDK-client tested); the **BYO tier** (Bearer token → the buyer's saved tokens)
  end-to-end (open tier proven, BYO untested).
- **Known edge:** a valid connector token with NO saved instrument returns 401
  (confusing) — should say "set up your instrument first". No rate-limit on
  `/api/mcp` yet (cheap deterministic check, low urgency).

## Open items — start here (checklist)
Config to verify (in Vercel; theirs):
- [ ] `SESSION_SECRET` set + strong (else session/magic-link cookies are forgeable — security-critical).
- [ ] Stripe **webhook** → `/api/stripe-webhook` delivering 200 (durable fulfillment; redirect-claim is only the happy path).
- [ ] **Resend** sending the magic-link — almost certainly the `REQUEST_SENDER` domain isn't verified in Resend. Returning buyers are locked out until this works.

Verify (product isn't "proven" until these pass):
- [ ] The connector in **real Claude Code / Cursor** (only SDK-client tested).
- [ ] The **BYO tier** end-to-end: save tokens on `/instrument` → issue token → an MCP client with that Bearer hits `/api/mcp`.

Code (ours, small):
- [ ] Friendly message when a valid connector token has no saved instrument (currently a bare 401).
- [ ] Reasonable-use rate-limit on `/api/mcp` (cheap deterministic check, low urgency).
- [ ] **Web copy polish** — front-to-back read-through; known stale: `/steward` "…the studio" line (studio retired), `/request` now redundant with `/instrument`.
- [ ] Small: floor pacing; font/spacing axes in the check; dead `provideContext` branch in `webmcp.ts`.

Theirs (non-code):
- [ ] The **video** (Gemini-Inspector take exists; full session at the end). See `docs/DEMO-VIDEO.md`.

Parked / future: the #2 decision (below); Phase D (authoritative engine, waits on unfreeze).


- **#2 purist vs. pragmatic.** Does paid BYO route through the engine only (clean
  engine/showcase separation, but the paid live-check waits on unfreeze), or does
  one shared `lib/check.ts` power open *and* paid-at-launch (paid ships sooner,
  freeze-independent, but sirocco carries a check)? Honesty holds either way if a
  single module backs both tiers. Leaning pragmatic; it's a brand call.

## Entitlement schema (confirmed shape, for Phase A)
- One paid grant, demo ungated (no row, no auth, ever).
- `customers` (email, payment-ref) · `entitlements` (`kind='byo_capability'`,
  lifetime/founder, status) · `connector_tokens` (per-endpoint bearer, hashed) ·
  `minted_instruments` (jsonb tokens, Phase C) · rate-cap accounting (Phase B).

## Notes / gotchas (so we don't relearn)
- Astro scoped CSS ≠ innerHTML-injected nodes (result styles live in `global.css`).
- The hard check is `f(reference_tokens, code)` — the tokens are sirocco's own, so
  the engine holds nothing we lack; that's *why* the open check can run locally.
- `check.ts` Phase-0 simplifications: colors match on RGB (alpha ignored), CSS
  named colors not resolved, radii compare on computed px (0.25rem honors 4px).
  Tune for parity if/when we compare against the engine.
- Env needed in Vercel: `RESEND_API_KEY`, `REQUEST_INBOX`, `REQUEST_SENDER`,
  `ANTHROPIC_API_KEY`; **for BYO commerce:** `DATABASE_URL` (Neon), `STRIPE_SECRET_KEY`,
  `STRIPE_WEBHOOK_SECRET` (webhook → `/api/stripe-webhook`, event
  `checkout.session.completed`), `SESSION_SECRET` (random, for HMAC). Schema
  auto-creates on first fulfillment (`initSchema`). (`SWATCHDOG_CONNECTOR_URL`
  optional override; dormant.)
- resvg for previews (no headless browser in the sandbox).
- `/lab` — unlisted (noindex), tool console that drives the same `buildTools` the
  WebMCP surface registers. The agent's-eye view, any browser, for evaluating and
  sharpening tool copy/outputs without Canary. Not linked in nav.
- **Shareable artifact** (last): the live run exists (`/api/run`); what remains is
  capturing/packaging a take (recording, maybe a shareable permalink of a run).
  Possible upgrade: true token-streaming for the "watch it think" feel (currently
  batch-then-play). Not load-bearing.
