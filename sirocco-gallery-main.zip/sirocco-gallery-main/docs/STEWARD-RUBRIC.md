# The steward's rubric

Internal. The methodology that defines what it means to *honor* an instrument —
beyond whether the tokens are real. This is the steward's actual value: the
deterministic engine (swatchdog) answers "are these legitimate tokens?"; the
rubric answers "are they used *right*, and does the build honor the intent?"

It is single-sourced in `src/lib/steward-rubric.ts` (as a prompt fragment) and
used by the floor's live agent and the spirit judge. It is also the thing that
ships *with* the BYO connector — the buyer's own agent runs it. The steward is an
instrument the agent plays; this is the score.

## The layers

1. **Tokens are the floor, not the finish.**
   Every value must be a real token. The deterministic check enforces this. It is
   *necessary, not sufficient* — a build can use only real tokens and still be
   wrong (the accent flooding the surface, text and background inverted). That gap
   is everything below.

2. **Role.**
   Each token used for its kind:
   - background → a surface/background tone;
   - body text → a foreground tone, with **comfortable contrast** against that background;
   - border → a quiet border tone, close to the background;
   - **accent → a single note** — reserved for one small emphasis, never the surface or the body text.

3. **Register.**
   Stay in the instrument's register. A dark instrument reads dark (deep surface,
   light text); a light one reads light. Don't mix — a valid light-mode token used
   on a dark instrument is still off.

4. **Restraint & hierarchy.**
   Match the instrument's proportion and rhythm — its type scale, its spacing.
   Prefer restraint; let one thing lead. Density and weight should match the intent.

5. **Temperature & mood.**
   The result should *feel* like the instrument's intent — its warmth or cool, its
   quiet or its charge. (e.g. brass hour: "patina at low contrast, lamplight at
   high.")

6. **Spirit.**
   Finally: does it honor what the instrument is *for*? The right value used the
   wrong way still strays. This is the read tokens can't measure.

## How it's used
- **Floor live agent (`/api/run`)** — the builder drafts and revises by the rubric,
  so its output honors role/register/intent, not just membership.
- **Spirit judge (`/api/intent`)** — judges a build against items 2–6 (the layers
  the deterministic check can't see).
- **BYO connector (future)** — ships with the connector so the buyer's own agent
  judges *their* system by the same rubric.

## The honesty line
The deterministic check is the floor we must always meet (and never over-state).
The rubric is the layer above it — sirocco's, not the engine's. Keep them
separate in code and in copy.
