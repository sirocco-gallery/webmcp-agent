import type { APIRoute } from 'astro';
import { readSession } from '../../lib/auth';
import { entitledCustomerId, saveMinted, issueToken } from '../../lib/db';
import { normalize } from '../../lib/normalize';

export const prerender = false;
const json = (d: unknown, s = 200) => new Response(JSON.stringify(d), { status: s, headers: { 'Content-Type': 'application/json' } });

// Authed actions for the owner's instrument page:
//   save        — normalize pasted tokens and persist them
//   issue-token — mint a fresh connector token (shown once), revoking prior ones
export const POST: APIRoute = async ({ request }) => {
  const sess = readSession(request);
  if (!sess) return json({ error: 'not signed in' }, 401);

  let customerId: string | null;
  try {
    customerId = await entitledCustomerId(sess.email);
  } catch {
    return json({ error: 'store unavailable' }, 503);
  }
  if (!customerId) return json({ error: 'no entitlement' }, 403);

  let body: any = {};
  try {
    body = await request.json();
  } catch {
    /* ignore */
  }

  try {
    if (body.action === 'save') {
      const n = normalize(String(body.tokens ?? ''));
      if (!n.count) return json({ error: 'could not read any tokens from that', warnings: n.warnings }, 400);
      const name = typeof body.name === 'string' && body.name.trim() ? body.name.trim() : 'my instrument';
      await saveMinted(customerId, name, n.color, n.radius);
      return json({ ok: true, normalized: n });
    }
    if (body.action === 'issue-token') {
      return json({ ok: true, token: await issueToken(customerId) });
    }
    return json({ error: 'unknown action' }, 400);
  } catch (err) {
    console.error('[instrument] action failed', err);
    return json({ error: 'action failed' }, 500);
  }
};
