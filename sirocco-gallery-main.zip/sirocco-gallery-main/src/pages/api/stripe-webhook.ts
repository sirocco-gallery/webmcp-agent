import type { APIRoute } from 'astro';
import Stripe from 'stripe';
import { upsertCustomer, grantEntitlement, initSchema } from '../../lib/db';

export const prerender = false;

// Durable fulfillment: grant the BYO entitlement when checkout completes. The
// redirect-claim on /instrument is the happy path; this is the backstop.
export const POST: APIRoute = async ({ request }) => {
  const key = (import.meta.env.STRIPE_SECRET_KEY as string) ?? process.env.STRIPE_SECRET_KEY;
  const whSecret = (import.meta.env.STRIPE_WEBHOOK_SECRET as string) ?? process.env.STRIPE_WEBHOOK_SECRET;
  if (!key || !whSecret) return new Response('not configured', { status: 503 });

  const stripe = new Stripe(key);
  const sig = request.headers.get('stripe-signature') ?? '';
  const body = await request.text();

  let event: Stripe.Event;
  try {
    event = await stripe.webhooks.constructEventAsync(body, sig, whSecret);
  } catch {
    return new Response('bad signature', { status: 400 });
  }

  if (event.type === 'checkout.session.completed') {
    const s = event.data.object as Stripe.Checkout.Session;
    const email = s.customer_details?.email || s.customer_email;
    if (email && (s.payment_status === 'paid' || s.payment_status === 'no_payment_required')) {
      try {
        await initSchema();
        const id = await upsertCustomer(email, typeof s.customer === 'string' ? s.customer : undefined);
        await grantEntitlement(id);
      } catch (err) {
        console.error('[webhook] fulfillment failed', err);
        return new Response('fulfillment error', { status: 500 });
      }
    }
  }
  return new Response('ok');
};
