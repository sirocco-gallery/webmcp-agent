import type { APIRoute } from 'astro';
import { Resend } from 'resend';

export const prerender = false;

const RATE_WINDOW_MS = 60_000;
const recentByIp = new Map<string, number>();

function rateLimit(ip: string): boolean {
  const now = Date.now();
  const last = recentByIp.get(ip) ?? 0;
  if (now - last < RATE_WINDOW_MS) return false;
  recentByIp.set(ip, now);
  if (recentByIp.size > 1000) {
    for (const [k, t] of recentByIp) {
      if (now - t > RATE_WINDOW_MS) recentByIp.delete(k);
    }
  }
  return true;
}

const ALLOWED_HOSTS = new Set(['sirocco.gallery', 'www.sirocco.gallery']);

function sameSiteOrigin(request: Request): boolean {
  const origin = request.headers.get('origin');
  if (!origin) return true; // non-browser callers (curl) have no Origin
  try {
    const host = new URL(origin).hostname;
    return ALLOWED_HOSTS.has(host) || host.endsWith('.vercel.app');
  } catch {
    return false;
  }
}

export const POST: APIRoute = async ({ request, clientAddress }) => {
  if (!sameSiteOrigin(request)) {
    return new Response('forbidden', { status: 403 });
  }

  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return new Response('bad request', { status: 400 });
  }

  const honey = String(form.get('company') ?? '').trim();
  if (honey) {
    return new Response(JSON.stringify({ ok: true }), { status: 200 });
  }

  const email = String(form.get('email') ?? '').trim();
  const forId = String(form.get('for') ?? '').trim();

  if (!email || !email.includes('@') || email.length > 320) {
    return new Response('invalid email', { status: 400 });
  }

  const ip = clientAddress ?? 'unknown';
  if (!rateLimit(ip)) {
    return new Response('rate limited', { status: 429 });
  }

  const apiKey = import.meta.env.RESEND_API_KEY;
  const inbox = import.meta.env.REQUEST_INBOX ?? 'inquiries@sirocco.gallery';
  const sender =
    import.meta.env.REQUEST_SENDER ?? 'sirocco.gallery <requests@sirocco.gallery>';

  if (!apiKey) {
    console.warn('[request] RESEND_API_KEY not set — request not sent', { email, forId });
    return new Response(JSON.stringify({ ok: true, queued: false }), { status: 200 });
  }

  try {
    const resend = new Resend(apiKey);
    const subject = forId
      ? `access request — instrument ${forId}`
      : `access request`;

    await resend.emails.send({
      from: sender,
      to: inbox,
      replyTo: email,
      subject,
      text: [
        `new access request`,
        ``,
        `email: ${email}`,
        forId ? `instrument: ${forId}` : null,
        `ip: ${ip}`,
        `timestamp: ${new Date().toISOString()}`,
      ]
        .filter(Boolean)
        .join('\n'),
    });

    return new Response(JSON.stringify({ ok: true }), { status: 200 });
  } catch (err) {
    console.error('[request] resend error', err);
    return new Response('upstream error', { status: 502 });
  }
};
