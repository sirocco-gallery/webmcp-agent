import type { APIRoute } from 'astro';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { WebStandardStreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js';
import { z } from 'zod';
import { checkDrift } from '../../lib/check';
import { normalize } from '../../lib/normalize';
import { STEWARD_RUBRIC } from '../../lib/steward-rubric';
import { instruments, getInstrument } from '../../data/instruments';
import { getReferenceTokens, getTokenCounts } from '../../data/tokens';
import { getMintedByToken, type MintedInstrument } from '../../lib/store';

export const prerender = false;

// The sirocco MCP connector — the steward, in the buyer's coding agent.
//
//  open tier   (no token): tools over the six house instruments. Free; the MCP
//              twin of the in-browser WebMCP surface. "Add sirocco to your agent."
//  byo tier    (valid Bearer token): the same check bound to the buyer's own
//              minted instrument. The $150 product.
//
// Deterministic + the rubric only — no LLM, no swatchdog. The buyer's own agent
// does the rubric reasoning. Freeze-safe and ~zero marginal cost.

const text = (value: unknown) => ({
  content: [{ type: 'text' as const, text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }],
});

function buildServer(owner: MintedInstrument | null): McpServer {
  const server = new McpServer({ name: 'sirocco', version: '0.1.0' });

  // The steward's rubric — as a resource and a tool, so any client can read it.
  server.registerResource(
    'steward-rubric',
    'sirocco://steward/rubric',
    { title: 'The steward’s rubric', description: 'How to honor an instrument beyond the tokens.', mimeType: 'text/markdown' },
    async () => ({ contents: [{ uri: 'sirocco://steward/rubric', text: STEWARD_RUBRIC }] }),
  );
  server.registerTool(
    'steward_rubric',
    { title: 'The steward’s rubric', description: 'Return the rubric for honoring an instrument: role, register, restraint, temperature, spirit — the layers the deterministic check can’t see.', inputSchema: {} },
    async () => text(STEWARD_RUBRIC),
  );

  // normalize — both tiers.
  server.registerTool(
    'normalize_tokens',
    {
      title: 'Normalize design tokens',
      description: 'Turn a messy design system (CSS custom properties, JSON / Tokens Studio, a Tailwind theme, or raw CSS) into a canonical token set: color, radius, space, font, plus the detected format and warnings.',
      inputSchema: { tokens: z.string().describe('Your design tokens as text.') },
    },
    async ({ tokens }) => text(normalize(String(tokens ?? ''))),
  );

  if (owner) {
    // ── BYO tier: bound to the buyer's own instrument ──
    server.registerTool(
      'check_design_drift',
      {
        title: 'Check drift against your instrument',
        description: `The steward. Check CSS against YOUR instrument “${owner.name}” — every color and corner — and get each drift named: what you wrote vs. the exact token expected. Deterministic. Then judge the result against the steward rubric (role, register, restraint, temperature, spirit).`,
        inputSchema: { code: z.string().describe('The CSS to check.') },
      },
      async ({ code }) => {
        const src = String(code ?? '');
        if (!src.trim()) return text({ error: 'nothing to check — pass the CSS' });
        return text(checkDrift({ color: owner.color, radius: owner.radius }, src));
      },
    );
    server.registerTool(
      'get_my_instrument',
      { title: 'Your instrument', description: 'Your minted instrument: name and the reference tokens the steward enforces.', inputSchema: {} },
      async () => text({ name: owner.name, color: owner.color, radius: owner.radius }),
    );
  } else {
    // ── open tier: the six house instruments ──
    server.registerTool(
      'list_instruments',
      { title: 'List instruments', description: 'List the six house instruments — each a curated, named design-token set the steward enforces.', inputSchema: {} },
      async () =>
        text(
          instruments.map((i) => ({
            id: i.id,
            name: i.name,
            tags: i.tags,
            mode: i.specs.find((s) => s.label === 'mode')?.value ?? '',
            palette: i.palette,
            tokens: getTokenCounts(i.id)?.total ?? 0,
          })),
        ),
    );
    server.registerTool(
      'get_instrument',
      { title: 'Get instrument', description: 'Full details for one house instrument by id.', inputSchema: { id: z.string().describe('Instrument id, e.g. "001".') } },
      async ({ id }) => {
        const i = getInstrument(String(id ?? ''));
        return text(i ? { id: i.id, name: i.name, description: i.description, tags: i.tags, palette: i.palette } : { error: `no instrument with id "${id}"` });
      },
    );
    server.registerTool(
      'check_design_drift',
      {
        title: 'Check design drift',
        description: 'The steward. Check CSS against a house instrument’s exact tokens (color + radius); each drift comes back named with the expected token. Deterministic. Then judge against the steward rubric. (Bring your own tokens to bind this to your system.)',
        inputSchema: { instrument_id: z.string().describe('Instrument id, e.g. "001".'), code: z.string().describe('The CSS to check.') },
      },
      async ({ instrument_id, code }) => {
        const ref = getReferenceTokens(String(instrument_id ?? ''));
        if (!ref) return text({ error: `no instrument with id "${instrument_id}"` });
        const src = String(code ?? '');
        if (!src.trim()) return text({ error: 'nothing to check — pass the CSS' });
        return text(checkDrift(ref, src));
      },
    );
  }

  return server;
}

const handle: APIRoute = async ({ request }) => {
  const auth = request.headers.get('authorization') ?? '';
  const token = auth.toLowerCase().startsWith('bearer ') ? auth.slice(7).trim() : '';
  const owner = token ? await getMintedByToken(token) : null;
  if (token && !owner) return new Response('invalid or expired connector token', { status: 401 });

  const transport = new WebStandardStreamableHTTPServerTransport({
    sessionIdGenerator: undefined, // stateless — fits serverless
    enableJsonResponse: true,
  });
  const server = buildServer(owner);
  await server.connect(transport);
  return transport.handleRequest(request);
};

export const ALL = handle;
