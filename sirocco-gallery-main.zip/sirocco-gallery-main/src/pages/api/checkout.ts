import type { APIRoute } from 'astro';
import Stripe from 'stripe';
import { publicOrigin } from '../../lib/origin';

export const prerender = false;

// Create a Stripe Checkout session for the Founder's BYO ($150, one-time). Inline
// price_data — no pre-made product needed. On success Stripe returns to
// /instrument?session={ID}, which claims the entitlement.
export const POST: APIRoute = async ({ request }) => {
  const key = (import.meta.env.STRIPE_SECRET_KEY as string) ?? process.env.STRIPE_SECRET_KEY;
  if (!key) return new Response(JSON.stringify({ error: 'checkout is not configured yet' }), { status: 503 });

  const origin = publicOrigin(request);
  let email = '';
  try {
    const b = await request.json();
    email = typeof b.email === 'string' ? b.email : '';
  } catch {
    /* email optional */
  }

  try {
    const stripe = new Stripe(key);
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: [
        {
          quantity: 1,
          price_data: {
            currency: 'usd',
            unit_amount: 15000,
            product_data: { name: "sirocco — Founder's BYO", description: 'The steward on your own tokens, in your coding agent. One-time, lifetime.' },
          },
        },
      ],
      customer_email: email || undefined,
      success_url: `${origin}/instrument?session={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/mint`,
      allow_promotion_codes: true,
    });
    return new Response(JSON.stringify({ url: session.url }), { headers: { 'Content-Type': 'application/json' } });
  } catch (err) {
    console.error('[checkout] failed', err);
    return new Response(JSON.stringify({ error: 'could not start checkout' }), { status: 502 });
  }
};
