import type { APIRoute } from 'astro';
import Anthropic from '@anthropic-ai/sdk';
import { getTokenSet } from '../../data/tokens';
import { STEWARD_RUBRIC } from '../../lib/steward-rubric';

export const prerender = false;

// The soft layer: an intent-based judgment, complementing the deterministic hard
// check. Vendor-agnostic to the public; powered by Claude server-side. No
// swatchdog. Capped-public: rate-limited because each call is a paid LLM call.
const MODEL = 'claude-sonnet-4-6';
const MAX_CODE = 50_000;

const WINDOW_MS = 5 * 60_000;
const MAX_PER_WINDOW = 10;
const hits = new Map<string, number[]>();
function rateLimit(ip: string): boolean {
  const now = Date.now();
  const arr = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW_MS);
  if (arr.length >= MAX_PER_WINDOW) {
    hits.set(ip, arr);
    return false;
  }
  arr.push(now);
  hits.set(ip, arr);
  if (hits.size > 2000) {
    for (const [k, v] of hits) if (!v.some((t) => now - t < WINDOW_MS)) hits.delete(k);
  }
  return true;
}

const ALLOWED_HOSTS = new Set(['sirocco.gallery', 'www.sirocco.gallery']);
function sameSiteOrigin(request: Request): boolean {
  const origin = request.headers.get('origin');
  if (!origin) return true;
  try {
    const h = new URL(origin).hostname;
    return ALLOWED_HOSTS.has(h) || h.endsWith('.vercel.app');
  } catch {
    return false;
  }
}

// Raw JSON Schema for structured output (no zod — avoids the SDK helper's
// zod-v4 coupling). additionalProperties:false is required by structured outputs.
const SOFT_SCHEMA = {
  type: 'object',
  properties: {
    verdict: { type: 'string', enum: ['honors', 'mixed', 'strays'] },
    notes: { type: 'array', items: { type: 'string' } },
  },
  required: ['verdict', 'notes'],
  additionalProperties: false,
};
const VERDICTS = ['honors', 'mixed', 'strays'];

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });

export const POST: APIRoute = async ({ request, clientAddress }) => {
  if (!sameSiteOrigin(request)) return new Response('forbidden', { status: 403 });

  let body: { instrument_id?: unknown; code?: unknown; hard?: unknown };
  try {
    body = await request.json();
  } catch {
    return json({ error: 'bad request' }, 400);
  }

  const instrumentId = typeof body.instrument_id === 'string' ? body.instrument_id : '';
  const code = typeof body.code === 'string' ? body.code : '';
  if (!code.trim()) return json({ error: 'nothing to weigh' }, 400);
  if (code.length > MAX_CODE) return json({ error: 'code too large' }, 413);

  const set = getTokenSet(instrumentId);
  if (!set) return json({ error: 'no instrument by that id' }, 404);

  const apiKey = import.meta.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    console.warn('[intent] ANTHROPIC_API_KEY not set — soft check unavailable');
    return json({ error: 'the spirit check is not configured yet' }, 503);
  }

  const ip = clientAddress ?? 'unknown';
  if (!rateLimit(ip)) return json({ error: 'give the steward a moment' }, 429);

  const colorSummary = Object.entries(set.color).map(([k, v]) => `${k} ${v}`).join(', ');
  const radiusSummary = Object.entries(set.radius).map(([k, v]) => `${k} ${v}`).join(', ');

  let hardSummary = 'not provided';
  const hard = body.hard as any;
  if (hard && typeof hard === 'object') {
    if (hard.ok) {
      hardSummary = 'clean — no token drift';
    } else if (Array.isArray(hard.violations)) {
      hardSummary =
        hard.violations
          .map((v: any) => `${v.axis}: found ${v.found}, expected ${v.expected} (${v.expectedValue})`)
          .join('; ') || 'drift reported';
    }
  }

  const system = `You are the steward of "${set.name}", a design instrument from sirocco.gallery.
Its intent: "${set.intent}"

A separate deterministic checker already handles exact token drift (item 1 below). Your job is the layer above it — judge whether the submitted CSS honors the instrument by the steward's rubric, items 2–6:

${STEWARD_RUBRIC}

Rules:
- Do not restate token membership (item 1); the deterministic checker covers it.
- Name only what items 2–6 reveal — e.g. the accent used as a flood instead of a single note, an inverted role, a flattened hierarchy, a register or temperature that betrays the intent.
- Be specific to THIS code and THIS instrument. No generic design advice.
- Be concise and exact, in a restrained editorial voice.
- If the code honors the instrument, say so plainly.

Return a verdict — "honors", "mixed", or "strays" — and 1 to 3 short notes (one sentence each).`;

  const userMsg = `Instrument tokens (reference):
- color: ${colorSummary}
- radius: ${radiusSummary}

Deterministic checker result: ${hardSummary}

CSS under review:
${code}`;

  try {
    const client = new Anthropic({ apiKey });
    const res = await client.messages.create({
      model: MODEL,
      max_tokens: 1024,
      system,
      messages: [{ role: 'user', content: userMsg }],
      output_config: { format: { type: 'json_schema', schema: SOFT_SCHEMA } },
    } as any);
    const textBlock = (res.content as any[]).find((b) => b.type === 'text');
    if (!textBlock?.text) return json({ error: 'no reading' }, 502);
    let parsed: any;
    try {
      parsed = JSON.parse(textBlock.text);
    } catch {
      return json({ error: 'unparseable reading' }, 502);
    }
    const verdict = parsed?.verdict;
    if (!VERDICTS.includes(verdict)) return json({ error: 'the steward was unsure' }, 502);
    const notes = Array.isArray(parsed?.notes)
      ? parsed.notes.filter((n: any) => typeof n === 'string').slice(0, 3)
      : [];
    return json({ soft: { verdict, notes } });
  } catch (err) {
    // Real cause stays server-side; the public response says nothing it shouldn't.
    console.error('[intent] anthropic error', err);
    return json({ error: 'upstream error' }, 502);
  }
};
