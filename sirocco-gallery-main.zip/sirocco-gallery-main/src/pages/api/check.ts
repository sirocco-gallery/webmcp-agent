import type { APIRoute } from 'astro';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import { getReferenceTokens } from '../../data/tokens';

// RESERVED — the authoritative hosted-engine path. The open demo no longer calls
// this: its checks run locally via src/lib/check.ts so an agent walking the open
// surface can't generate volume against the review-frozen engine. Kept dormant
// for the paid path (live check on a buyer's own tokens), wired once the engine
// is out of review.
export const prerender = false;

// The swatchdog connector is authless and read-only. We never modify it —
// we only call check_design_drift, server-to-server. Override via env if needed.
const CONNECTOR_URL =
  import.meta.env.SWATCHDOG_CONNECTOR_URL ??
  'https://swatchdog-connector-970396648818.us-central1.run.app/mcp';

const MAX_CODE = 50_000;

// Same origin posture as /api/request — Astro's blanket check is off globally,
// so each route guards itself.
const ALLOWED_HOSTS = new Set(['sirocco.gallery', 'www.sirocco.gallery']);
function sameSiteOrigin(request: Request): boolean {
  const origin = request.headers.get('origin');
  if (!origin) return true; // non-browser callers (curl) have no Origin
  try {
    const host = new URL(origin).hostname;
    return ALLOWED_HOSTS.has(host) || host.endsWith('.vercel.app');
  } catch {
    return false;
  }
}

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });

export const POST: APIRoute = async ({ request }) => {
  if (!sameSiteOrigin(request)) return new Response('forbidden', { status: 403 });

  let body: { instrument_id?: unknown; code?: unknown };
  try {
    body = await request.json();
  } catch {
    return json({ error: 'bad request' }, 400);
  }

  const instrumentId = typeof body.instrument_id === 'string' ? body.instrument_id : '';
  const code = typeof body.code === 'string' ? body.code : '';

  if (!code.trim()) return json({ error: 'nothing to check' }, 400);
  if (code.length > MAX_CODE) return json({ error: 'code too large' }, 413);

  const tokens = getReferenceTokens(instrumentId);
  if (!tokens) return json({ error: 'no instrument by that id' }, 404);

  const transport = new StreamableHTTPClientTransport(new URL(CONNECTOR_URL));
  const client = new Client({ name: 'sirocco-steward', version: '0.1.0' });

  try {
    await client.connect(transport);
    const result = await client.callTool({
      name: 'check_design_drift',
      arguments: { reference_tokens: tokens, code, source: 'css' },
    });

    const content = result.content as Array<{ type: string; text?: string }> | undefined;
    const block = Array.isArray(content) ? content.find((c) => c.type === 'text') : undefined;
    if (!block?.text) return json({ error: 'unexpected connector response' }, 502);

    const hard = JSON.parse(block.text);
    return json({ hard });
  } catch (err) {
    console.error('[check] swatchdog error', err);
    return json({ error: 'upstream error' }, 502);
  } finally {
    await client.close().catch(() => {});
  }
};
