import type { APIRoute } from 'astro';
import Anthropic from '@anthropic-ai/sdk';
import { getInstrument } from '../../data/instruments';
import { getTokenSet, getReferenceTokens, getTokenCounts } from '../../data/tokens';
import { checkDrift } from '../../lib/check';
import { DRIFT, cleanPreview, type Beat, type PreviewState, type RunInstrument } from '../../lib/run';
import { STEWARD_RUBRIC } from '../../lib/steward-rubric';

export const prerender = false;

// The real-agent run behind "the floor". A live Anthropic tool-use loop drafts a
// panel from the instrument's intent (NOT its exact tokens), calls the real,
// local check_design_drift, reads the named drift, and corrects from that
// feedback until clean — the steward teaching the agent the system. Freeze-safe:
// the only tool is the local checker; no swatchdog. Emits the same Beat shape the
// scripted stage consumes. Capped-public: each run is a paid model loop.
// Haiku 4.5 for speed — the task is bounded and the steward's feedback is
// explicit, so a fast model converges fine and the run feels snappier.
const MODEL = 'claude-haiku-4-5-20251001';
const MAX_STEPS = 5;

const WINDOW_MS = 10 * 60_000;
const MAX_PER_WINDOW = 6;
const hits = new Map<string, number[]>();
function rateLimit(ip: string): boolean {
  const now = Date.now();
  const arr = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW_MS);
  if (arr.length >= MAX_PER_WINDOW) {
    hits.set(ip, arr);
    return false;
  }
  arr.push(now);
  hits.set(ip, arr);
  if (hits.size > 2000) {
    for (const [k, v] of hits) if (!v.some((t) => now - t < WINDOW_MS)) hits.delete(k);
  }
  return true;
}

const ALLOWED_HOSTS = new Set(['sirocco.gallery', 'www.sirocco.gallery']);
function sameSiteOrigin(request: Request): boolean {
  const origin = request.headers.get('origin');
  if (!origin) return true;
  try {
    const h = new URL(origin).hostname;
    return ALLOWED_HOSTS.has(h) || h.endsWith('.vercel.app');
  } catch {
    return false;
  }
}

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });

export const POST: APIRoute = async ({ request, clientAddress }) => {
  if (!sameSiteOrigin(request)) return new Response('forbidden', { status: 403 });

  let body: { instrument_id?: unknown };
  try {
    body = await request.json();
  } catch {
    return json({ error: 'bad request' }, 400);
  }
  const id = typeof body.instrument_id === 'string' ? body.instrument_id : '';

  const meta = getInstrument(id);
  const set = getTokenSet(id);
  const ref = getReferenceTokens(id);
  const counts = getTokenCounts(id);
  if (!meta || !set || !ref || !counts) return json({ error: 'no instrument by that id' }, 404);

  const apiKey = import.meta.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    console.warn('[run] ANTHROPIC_API_KEY not set — live run unavailable');
    return json({ error: 'the live run is not configured yet' }, 503);
  }

  const ip = clientAddress ?? 'unknown';
  if (!rateLimit(ip)) return json({ error: 'the model is busy — give it a moment' }, 429);

  const mode = meta.specs.find((s) => s.label === 'mode')?.value ?? '';
  const inst: RunInstrument = { id, name: meta.name, mode, tokenTotal: counts.total, color: set.color, radius: set.radius };

  // Pin the register so dual-mode instruments don't drift light↔dark between runs:
  // derive it from the base surface's luminance and tell the agent to compose in it.
  const hexLum = (hex: string) => {
    const h = hex.replace('#', '');
    if (h.length < 6) return 0.5;
    const r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16);
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  };
  const baseColor = set.color['bg.base'] ?? set.color['bg.surface'] ?? Object.values(set.color)[0] ?? '#000000';
  const register = hexLum(baseColor) < 0.45 ? 'dark' : 'light';

  const grab = (css: string, prop: string) => {
    const m = css.match(new RegExp(prop + '\\s*:\\s*([^;}]+)', 'i'));
    return m ? m[1].trim() : '';
  };
  const hexIn = (s: string) => {
    const m = s.match(/#[0-9a-f]{3,8}|rgba?\([^)]*\)|hsla?\([^)]*\)/i);
    return m ? m[0] : '';
  };
  // Drive the preview from the agent's actual CSS so the panel shows its real
  // draft, then its real correction. Fall back to canonical vars on a miss.
  const previewFor = (css: string, ok: boolean): PreviewState => {
    const fb: any = ok ? cleanPreview(inst) : { ...DRIFT };
    const bg = hexIn(grab(css, 'background')) || fb.bg;
    const text = hexIn(grab(css, 'color')) || fb.text;
    const border = hexIn(grab(css, 'border')) || fb.border;
    const radius = grab(css, 'border-radius') || fb.radius;
    return { phase: ok ? 'clean' : 'drift', bg, text, border, radius, accent: ok ? fb.accent : text || fb.accent, css };
  };

  const system = `You are an autonomous build agent working on "${set.name}", a design instrument.
Its intent: "${set.intent}"

Compose in this instrument's ${register} register — its surface reads ${register}.

Your task: write a single CSS \`.panel\` rule — background, text color, a 1px border, and a border-radius — that honors this instrument by the steward's rubric:

${STEWARD_RUBRIC}

The corner radii are ${Object.values(set.radius).join(', ')} — use one of them. You do NOT have the palette colors; discover them: draft your best guesses from the intent and the rubric, call check_design_drift, and the steward returns the exact nearest token for each color that drifts. Adopt those exact values — each kept in its role — and re-check until it comes back clean. Only the four properties above.

Keep each spoken line to ONE short, plain sentence (what you're doing and why) — no preamble, no restating tokens. Always call the tool after writing or revising CSS.`;

  const checkTool = {
    name: 'check_design_drift',
    description:
      "Check a CSS snippet against the instrument's exact tokens (color + radius). Returns ok, and for any drift the value you used and the exact value expected.",
    input_schema: {
      type: 'object',
      properties: { css: { type: 'string', description: 'The full .panel CSS rule to check.' } },
      required: ['css'],
    },
  };

  const beats: Beat[] = [{ role: 'sys', text: `session — ${set.name.toLowerCase()} · ${id}`, pause: 480 }];

  try {
    const client = new Anthropic({ apiKey });
    const messages: Anthropic.MessageParam[] = [
      { role: 'user', content: 'Build the panel, then check and refine until it honors the instrument.' },
    ];

    let clean = false;
    for (let step = 0; step < MAX_STEPS && !clean; step++) {
      const res = await client.messages.create({
        model: MODEL,
        max_tokens: 800,
        system,
        tools: [checkTool as any],
        messages,
      });
      messages.push({ role: 'assistant', content: res.content });

      const toolResults: Anthropic.ToolResultBlockParam[] = [];
      for (const block of res.content as any[]) {
        if (block.type === 'text' && block.text.trim()) {
          beats.push({ role: 'agent', text: block.text.trim(), pause: 760 });
        } else if (block.type === 'tool_use' && block.name === 'check_design_drift') {
          const css = String(block.input?.css ?? '');
          const hard = checkDrift(ref, css);
          beats.push({ role: 'tool', text: 'check_design_drift → measuring color + radius', pause: 520, preview: previewFor(css, hard.ok) });
          if (hard.ok) {
            beats.push({ role: 'verdict', tone: 'clean', text: `clean · honors ${set.name}`, pause: 0 });
            clean = true;
          } else {
            for (const v of hard.violations) {
              const line = `drift · ${v.axis} · found ${v.found}` + (v.expected ? ` → expected ${v.expected} ${v.expectedValue}` : '');
              beats.push({ role: 'result', tone: 'drift', text: line, pause: 300 });
            }
            beats.push({ role: 'result', tone: 'drift', text: `${hard.count} ${hard.count === 1 ? 'drift' : 'drifts'} from ${set.name}`, pause: 640 });
          }
          toolResults.push({ type: 'tool_result', tool_use_id: block.id, content: JSON.stringify(hard) });
        }
      }

      if (clean) break;
      if (!toolResults.length) break; // model stopped calling the tool
      messages.push({ role: 'user', content: toolResults });
    }

    if (!clean) {
      beats.push({ role: 'sys', text: 'run paused — open the studio to finish by hand', pause: 0 });
    }

    return json({ beats });
  } catch (err) {
    console.error('[run] anthropic error', err);
    return json({ error: 'the run could not complete' }, 502);
  }
};
