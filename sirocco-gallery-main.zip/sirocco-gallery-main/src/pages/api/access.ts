import type { APIRoute } from 'astro';
import { Resend } from 'resend';
import { entitledCustomerId } from '../../lib/db';
import { makeToken } from '../../lib/auth';
import { publicOrigin } from '../../lib/origin';

export const prerender = false;

// Returning buyer: email a magic-link if (and only if) the address is entitled.
// Always responds ok, so it never reveals who has access.
export const POST: APIRoute = async ({ request }) => {
  let email = '';
  try {
    const b = await request.json();
    email = (typeof b.email === 'string' ? b.email : '').trim().toLowerCase();
  } catch {
    /* ignore */
  }
  const ok = () => new Response(JSON.stringify({ ok: true }), { headers: { 'Content-Type': 'application/json' } });
  if (!email.includes('@')) return ok();

  try {
    const id = await entitledCustomerId(email);
    if (id) {
      const token = makeToken({ email }, 30 * 60 * 1000); // 30 min
      const link = `${publicOrigin(request)}/instrument?k=${encodeURIComponent(token)}`;
      const apiKey = (import.meta.env.RESEND_API_KEY as string) ?? process.env.RESEND_API_KEY;
      const from = (import.meta.env.REQUEST_SENDER as string) ?? process.env.REQUEST_SENDER ?? 'sirocco <noreply@sirocco.gallery>';
      if (apiKey) {
        const resend = new Resend(apiKey);
        await resend.emails.send({ from, to: email, subject: 'your sirocco instrument', text: `Open your instrument:\n\n${link}\n\nThis link works for 30 minutes.` });
      }
    }
  } catch (err) {
    console.error('[access] failed', err);
  }
  return ok();
};
