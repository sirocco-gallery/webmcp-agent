// The public origin of a request. On Vercel, request.url's host can come through
// as "localhost" — so build the origin from the forwarded headers (which carry
// the real domain), with a PUBLIC_SITE_URL override and a sane fallback.
export function publicOrigin(request: Request): string {
  const env = (import.meta.env.PUBLIC_SITE_URL as string) || process.env.PUBLIC_SITE_URL;
  if (env) return env.replace(/\/+$/, '');
  const host = (request.headers.get('x-forwarded-host') || request.headers.get('host') || 'sirocco.gallery').split(',')[0].trim();
  const local = host.startsWith('localhost') || host.startsWith('127.');
  const proto = (request.headers.get('x-forwarded-proto') || (local ? 'http' : 'https')).split(',')[0].trim();
  return `${proto}://${host}`;
}
