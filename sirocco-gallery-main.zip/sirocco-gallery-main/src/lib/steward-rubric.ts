// The steward's rubric — single source of truth (see docs/STEWARD-RUBRIC.md).
//
// What it means to honor an instrument, beyond whether the tokens are real. The
// deterministic check is the floor (are these legitimate tokens?); this is the
// layer above it (are they used right, and does the build honor the intent?).
// Used as a prompt fragment by the floor's live builder and the spirit judge,
// and it's what ships with the BYO connector for the buyer's own agent.

export const STEWARD_RUBRIC = `The steward's rubric — to honor an instrument, beyond the tokens:
1. Tokens are the floor. Every value must be a real token; that is necessary, not sufficient.
2. Role. Use each token for its kind: a surface/background tone for the background; a foreground tone for the text, with comfortable contrast against it; a quiet border tone for the border; the accent reserved for a single small emphasis — never the surface or the body text.
3. Register. Stay in the instrument's register — a dark instrument reads dark (deep surface, light text); a light one reads light. Don't mix.
4. Restraint & hierarchy. Match the instrument's proportion and rhythm; prefer restraint; let one thing lead.
5. Temperature & mood. The build should feel like the instrument's intent — its warmth or cool, its quiet or its charge.
6. Spirit. Finally, does it honor what the instrument is for? The right value used the wrong way still strays.`;
