// Pure token → export-format generators. Shared by the build script (instrument
// exports) and the /mint page (BYO downloads), so both produce identical output.
import type { TokenSet } from '../data/tokens/types';

export interface ExportableSet {
  name?: string;
  intent?: string;
  color: Record<string, string>;
  radius: Record<string, string>;
  space: Record<string, string>;
  font: Record<string, string>;
}

const AXES = ['color', 'radius', 'space', 'font'] as const;

const varName = (axis: string, key: string) => `${axis}-${key.replace(/\./g, '-')}`;

export const slug = (name?: string) =>
  (name ?? 'instrument').trim().replace(/\s+/g, '-').toLowerCase() || 'instrument';

export function toCss(t: ExportableSet): string {
  const lines: string[] = [];
  if (t.name) lines.push(`/* ${t.name} */`);
  if (t.intent) lines.push(`/* ${t.intent} */`);
  lines.push(':root {');
  for (const axis of AXES) {
    for (const [k, v] of Object.entries(t[axis])) lines.push(`  --${varName(axis, k)}: ${v};`);
  }
  lines.push('}', '');
  return lines.join('\n');
}

export function toScss(t: ExportableSet): string {
  const lines: string[] = [];
  if (t.name) lines.push(`// ${t.name}`);
  if (t.intent) lines.push(`// ${t.intent}`);
  lines.push('');
  for (const axis of AXES) {
    for (const [k, v] of Object.entries(t[axis])) lines.push(`$${varName(axis, k)}: ${v};`);
    lines.push('');
  }
  return lines.join('\n');
}

export function toJson(t: ExportableSet): string {
  return JSON.stringify(
    { name: t.name, color: t.color, radius: t.radius, space: t.space, font: t.font },
    null,
    2,
  );
}

export function toFigma(t: ExportableSet): string {
  const figmaType: Record<string, string> = {
    color: 'color',
    radius: 'borderRadius',
    space: 'spacing',
    font: 'other',
  };
  const out: Record<string, Record<string, { value: string; type: string }>> = {};
  for (const axis of AXES) {
    out[axis] = {};
    for (const [k, v] of Object.entries(t[axis])) out[axis][k] = { value: v, type: figmaType[axis] };
  }
  return JSON.stringify(out, null, 2);
}

export type { TokenSet };
