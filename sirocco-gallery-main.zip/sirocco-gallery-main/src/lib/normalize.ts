// BYO normalizer — turns a messy design system into sirocco's canonical token
// shape. Pure, client-safe, zero swatchdog. A minted set has the same shape as
// an instrument.
//
// v1 inputs: CSS custom properties, raw JSON, Tokens Studio / Figma.
// v2 inputs: Tailwind theme/config, and inference from raw CSS.

export type Axis = 'color' | 'radius' | 'space' | 'font';
export type Format = 'css' | 'json' | 'tailwind' | 'rawcss' | 'unknown';

export interface NormalizeResult {
  format: Format;
  color: Record<string, string>;
  radius: Record<string, string>;
  space: Record<string, string>;
  font: Record<string, string>;
  warnings: string[];
  count: number;
}

interface Entry {
  key: string;
  value: string;
  typeHint?: string;
}

// ── value detection ──
const HEX = /^#([0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i;
const isHex = (v: string) => HEX.test(v.trim());
const isColor = (v: string) => isHex(v) || /^(rgb|rgba|hsl|hsla)\(/i.test(v.trim());
const isLength = (v: string) => /^-?\d*\.?\d+(px|rem|em|%|vh|vw|pt)$/i.test(v.trim());

// ── key hints ──
const RADIUS_HINT = /(radius|corner|rounded|round)/i;
const SPACE_HINT = /(spac|gap|inset|margin|padding|sizing|scale)/i;
const FONT_HINT = /(font|family|leading|tracking|line-height|letter-spacing|typeface|type-)/i;
const COLOR_HINT =
  /(colou?r|bg|background|foreground|fg|text|border|accent|brand|ink|surface|fill|stroke|shade|tint|palette|hue)/i;

function classify(key: string, value: string): Axis | null {
  const k = key.toLowerCase();
  const v = String(value).trim();
  if (RADIUS_HINT.test(k) && (isLength(v) || /^\d/.test(v))) return 'radius';
  if (FONT_HINT.test(k)) return 'font';
  if (SPACE_HINT.test(k) && isLength(v)) return 'space';
  if (isColor(v)) return 'color';
  if (COLOR_HINT.test(k) && isColor(v)) return 'color';
  if (isLength(v)) return 'space';
  return null;
}

const TYPE_AXIS: Record<string, Axis> = {
  color: 'color',
  borderradius: 'radius',
  radius: 'radius',
  spacing: 'space',
  space: 'space',
  dimension: 'space',
  sizing: 'space',
  fontfamily: 'font',
  fontfamilies: 'font',
  fontsize: 'font',
  fontsizes: 'font',
  typography: 'font',
  other: 'font',
};

const AXIS_WORDS: Record<Axis, string[]> = {
  color: ['color', 'colour', 'colors', 'colours'],
  radius: ['radius', 'corner', 'rounded', 'radii'],
  space: ['space', 'spacing', 'gap', 'size', 'sizing'],
  font: ['font', 'fonts', 'type', 'text', 'typography'],
};

function toDotName(key: string, axis: Axis): string {
  let n = key.trim().replace(/^--/, '');
  n = n.replace(/([a-z0-9])([A-Z])/g, '$1-$2');
  n = n.replace(/[\/_\s.]+/g, '-').toLowerCase();
  let segs = n.split(/-+/).filter(Boolean);
  if (segs.length > 1 && AXIS_WORDS[axis].includes(segs[0])) segs = segs.slice(1);
  return segs.join('.') || 'token';
}

function normalizeValue(value: string, axis: Axis): string {
  let v = value.trim();
  if (axis === 'color' && isHex(v)) {
    v = v.toLowerCase();
    if (v.length === 4) v = '#' + v.slice(1).split('').map((c) => c + c).join('');
  }
  return v;
}

function canonicalize(entries: Entry[], format: Format, extraWarnings: string[] = []): NormalizeResult {
  const res: NormalizeResult = { format, color: {}, radius: {}, space: {}, font: {}, warnings: [...extraWarnings], count: 0 };
  for (const e of entries) {
    const v = String(e.value).trim();
    if (!v || v.startsWith('var(') || v.startsWith('{')) continue;
    let axis: Axis | undefined = e.typeHint ? TYPE_AXIS[e.typeHint.toLowerCase()] : undefined;
    if (!axis) axis = classify(e.key, v) ?? undefined;
    if (!axis) {
      res.warnings.push(`skipped "${e.key}" — couldn't classify`);
      continue;
    }
    let name = toDotName(e.key, axis);
    let base = name;
    let i = 2;
    while (name in res[axis]) name = `${base}.${i++}`;
    res[axis][name] = normalizeValue(v, axis);
    res.count += 1;
  }
  return res;
}

// ── parsers: v1 ──
function parseCssVars(input: string): Entry[] {
  const out: Entry[] = [];
  const re = /--([a-z0-9-_]+)\s*:\s*([^;]+);/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(input))) out.push({ key: m[1], value: m[2].trim() });
  return out;
}

function parseJsonTokens(obj: unknown): Entry[] {
  const out: Entry[] = [];
  const walk = (o: any, path: string) => {
    if (!o || typeof o !== 'object') return;
    for (const [k, v] of Object.entries(o)) {
      const p = path ? `${path}.${k}` : k;
      if (v && typeof v === 'object') {
        const leaf = v as any;
        if ('value' in leaf || '$value' in leaf) {
          out.push({
            key: p.replace(/\.(value|\$value)$/, ''),
            value: String(leaf.value ?? leaf.$value),
            typeHint: leaf.type ?? leaf.$type,
          });
        } else {
          walk(v, p);
        }
      } else if (typeof v === 'string' || typeof v === 'number') {
        out.push({ key: p, value: String(v) });
      }
    }
  };
  walk(obj, '');
  return out;
}

// ── parsers: v2 — Tailwind ──
function isTailwindShape(o: any): boolean {
  return (
    !!o &&
    typeof o === 'object' &&
    ('theme' in o || 'colors' in o || 'borderRadius' in o || 'fontFamily' in o || 'fontSize' in o)
  );
}

function tailwindEntriesFromObject(obj: any): Entry[] {
  const theme = obj.theme && typeof obj.theme === 'object' ? obj.theme : obj;
  const ext = theme.extend && typeof theme.extend === 'object' ? theme.extend : {};
  const pick = (k: string) => ({ ...(theme[k] || {}), ...(ext[k] || {}) });
  const out: Entry[] = [];
  const flat = (o: any, prefix: string, hint: string) => {
    for (const [k, v] of Object.entries(o)) {
      const name = k === 'DEFAULT' ? prefix || 'default' : prefix ? `${prefix}.${k}` : k;
      if (v && typeof v === 'object' && !Array.isArray(v)) flat(v, name, hint);
      else if (Array.isArray(v)) out.push({ key: name, value: String(v[0]), typeHint: hint });
      else if (typeof v === 'string' || typeof v === 'number') out.push({ key: name, value: String(v), typeHint: hint });
    }
  };
  flat(pick('colors'), '', 'color');
  flat(pick('borderRadius'), '', 'borderRadius');
  flat(pick('spacing'), '', 'spacing');
  for (const [k, v] of Object.entries(pick('fontFamily'))) {
    out.push({ key: k, value: Array.isArray(v) ? (v as any[]).join(', ') : String(v), typeHint: 'fontFamily' });
  }
  for (const [k, v] of Object.entries(pick('fontSize'))) {
    out.push({ key: k, value: Array.isArray(v) ? String((v as any[])[0]) : String(v), typeHint: 'fontSize' });
  }
  return out;
}

// Best-effort JS-object → object (Tailwind theme pasted as JS). Plain-value
// objects only; require()/functions are dropped with a warning upstream.
function looseParseObject(input: string): any | null {
  let s = input.trim();
  s = s.replace(/\/\*[\s\S]*?\*\//g, ''); // block comments first (may contain braces)
  s = s.replace(/([^:"'`\\])\/\/[^\n\r]*/g, '$1'); // line comments
  const a = s.indexOf('{');
  const b = s.lastIndexOf('}');
  if (a === -1 || b === -1 || b < a) return null;
  s = s.slice(a, b + 1);
  s = s.replace(/\b(?:require|import)\([^)]*\)/g, 'null'); // drop module refs (anywhere, incl. arrays)
  s = s.replace(/'/g, '"'); // single → double quotes
  s = s.replace(/,(\s*[}\]])/g, '$1'); // trailing commas
  s = s.replace(/([{,]\s*)([A-Za-z0-9_$][\w$-]*)(\s*:)/g, '$1"$2"$3'); // quote unquoted keys (incl. numeric, e.g. 500)
  try {
    return JSON.parse(s);
  } catch {
    return null;
  }
}

// ── parsers: v2 — raw CSS inference ──
const ROLE_NAMES = ['sm', 'md', 'lg', 'xl', '2xl', '3xl', '4xl'];
function inferFromCss(input: string): { entries: Entry[]; warnings: string[] } {
  const out: Entry[] = [];
  const seen = new Map<string, string>();
  const idx: Record<string, number> = { bg: 0, text: 0, border: 0, accent: 0, color: 0 };
  const radii = new Set<string>();
  const declRe = /([\w-]+)\s*:\s*([^;{}]+)[;}]/g;
  let m: RegExpExecArray | null;
  while ((m = declRe.exec(input))) {
    const prop = m[1].toLowerCase();
    const val = m[2].trim();
    if (prop.startsWith('--')) continue;
    if (/radius/.test(prop)) {
      for (const len of val.match(/-?\d*\.?\d+(px|rem|em)\b/g) || []) radii.add(len.toLowerCase());
      continue;
    }
    for (const hex of val.match(/#[0-9a-fA-F]{3,8}\b/g) || []) {
      const norm = hex.toLowerCase();
      if (seen.has(norm)) continue;
      let role = 'color';
      if (/background/.test(prop)) role = 'bg';
      else if (prop === 'color') role = 'text';
      else if (/border/.test(prop)) role = 'border';
      else if (/(fill|stroke|outline|shadow|accent)/.test(prop)) role = 'accent';
      const name = `${role}.${++idx[role]}`;
      seen.set(norm, name);
      out.push({ key: name, value: norm, typeHint: 'color' });
    }
  }
  [...radii]
    .sort((a, b) => parseFloat(a) - parseFloat(b))
    .forEach((r, i) => out.push({ key: ROLE_NAMES[i] ?? `r${i + 1}`, value: r, typeHint: 'borderRadius' }));
  const warnings = [
    'Inferred from raw CSS — colors are named by where they appear (bg / text / border / accent). Review the preview before you trust it.',
  ];
  return { entries: out, warnings };
}

// ── detection + dispatch ──
export function detectFormat(input: string): Format {
  const t = input.trim();
  if (/--[a-z0-9-]+\s*:/i.test(t)) return 'css';
  if (/module\.exports|export\s+default|require\(|tailwind|theme\s*:|extend\s*:/i.test(t)) return 'tailwind';
  if (t.startsWith('{') || t.startsWith('[')) return 'json';
  if (/\{[^{}]*[\w-]+\s*:[^{}]+\}/.test(t)) return 'rawcss';
  return 'unknown';
}

const empty = (format: Format, warning?: string): NormalizeResult => ({
  format,
  color: {},
  radius: {},
  space: {},
  font: {},
  warnings: warning ? [warning] : [],
  count: 0,
});

export function normalize(input: string): NormalizeResult {
  const format = detectFormat(input);

  if (format === 'css') return canonicalize(parseCssVars(input), 'css');

  if (format === 'rawcss') {
    const { entries, warnings } = inferFromCss(input);
    return canonicalize(entries, 'rawcss', warnings);
  }

  if (format === 'json' || format === 'tailwind') {
    // strict JSON first
    try {
      const obj = JSON.parse(input);
      if (isTailwindShape(obj)) return canonicalize(tailwindEntriesFromObject(obj), 'tailwind');
      return canonicalize(parseJsonTokens(obj), 'json');
    } catch {
      /* fall through to lenient JS-object parse */
    }
    const obj = looseParseObject(input);
    if (obj) {
      if (isTailwindShape(obj)) return canonicalize(tailwindEntriesFromObject(obj), 'tailwind');
      return canonicalize(parseJsonTokens(obj), 'json');
    }
    return empty(
      format,
      'Could not parse that config. Paste just the theme object (colors, borderRadius, spacing, fontFamily, fontSize) with plain values — drop require() and functions.',
    );
  }

  return empty(
    'unknown',
    'Could not detect a format. Paste CSS custom properties, a JSON / Tokens Studio set, a Tailwind theme, or raw CSS.',
  );
}
