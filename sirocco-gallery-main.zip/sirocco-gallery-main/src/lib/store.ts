// Persistence seam for the BYO connector. A connector token (the bearer a buyer's
// agent sends) resolves to that buyer's minted instrument. Wired to Neon in the
// commerce layer; until DATABASE_URL is set this returns null, so the connector
// serves only the open (house) tier.

export interface MintedInstrument {
  name: string;
  color: Record<string, string>;
  radius: Record<string, string>;
}

export async function getMintedByToken(token: string): Promise<MintedInstrument | null> {
  if (!token) return null;
  try {
    const mod = await import('./db');
    return await mod.mintedInstrumentByToken(token);
  } catch {
    // db not configured (no DATABASE_URL) — open tier only
    return null;
  }
}
