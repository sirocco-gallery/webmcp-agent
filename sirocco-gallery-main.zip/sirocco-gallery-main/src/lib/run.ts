// The run engine — the choreography behind "the floor".
//
// Produces a deterministic sequence of beats for one instrument: an agent
// drafting a panel, calling the real check, reading the named drift, revising to
// honor the tokens, and re-checking clean. The agent's narration is authored;
// the tool results are REAL — check_design_drift runs here, on the instrument's
// own reference tokens. The same script runs across any instrument, themed to it.
//
// A scripted producer today; the stage consumes Beats, so a real-agent producer
// can emit the same shape later without touching the stage.

import { checkDrift, type ReferenceTokens } from './check';

export interface RunInstrument {
  id: string;
  name: string;
  mode: string;
  tokenTotal: number;
  color: Record<string, string>;
  radius: Record<string, string>;
}

export type BeatRole = 'sys' | 'tool' | 'agent' | 'result' | 'verdict';

export interface PreviewState {
  phase: 'drift' | 'clean';
  bg: string;
  text: string;
  border: string;
  radius: string;
  accent: string;
  css: string;
}

export interface Beat {
  role: BeatRole;
  text: string;
  tone?: 'drift' | 'clean';
  pause: number; // ms to hold after this beat is revealed
  preview?: PreviewState; // apply to the build pane as this beat lands
}

// A deliberately off-palette draft. Colors drift (and draw the nearest-token
// suggestions — the money shot); the radius is left valid so the demo stays on
// color, where the engine's suggestions shine. Fallback drift vars for the live
// run live in DRIFT.
const DRIFT_COLORS = { bg: '#1e1e1e', text: '#ff3db5', border: '#3b82f6', accent: '#3b82f6' };
export const DRIFT: Omit<PreviewState, 'phase'> = {
  ...DRIFT_COLORS,
  radius: '8px',
  css: `.panel {\n  background: #1e1e1e;\n  color: #ff3db5;\n  border: 1px solid #3b82f6;\n  border-radius: 8px;\n}`,
};

// Pick a token by name preference, always falling back to a real member so the
// generated "clean" CSS is guaranteed to honor the set.
function pick(obj: Record<string, string>, patterns: RegExp[], fallbackIdx: number): string {
  const keys = Object.keys(obj);
  for (const p of patterns) {
    const k = keys.find((key) => p.test(key));
    if (k) return obj[k];
  }
  const vals = Object.values(obj);
  return vals[fallbackIdx] ?? vals[0] ?? '';
}

export function cleanPreview(inst: RunInstrument): PreviewState {
  const bg = pick(inst.color, [/bg\.surface/, /bg\.base/], 0);
  const text = pick(inst.color, [/text\.primary/, /text/], 0);
  const border = pick(inst.color, [/border\.subtle/, /border/], 0);
  const accent = pick(inst.color, [/^accent$/, /accent/, /border\.(brass|ember|moss|strong)/], 0);
  const radius = pick(inst.radius, [/lg/, /md/], Object.keys(inst.radius).length - 1);
  const css = `.panel {
  background: ${bg};
  color: ${text};
  border: 1px solid ${border};
  border-radius: ${radius};
}`;
  return { phase: 'clean', bg, text, border, radius, accent, css };
}

// One drift line — the expected clause only when the engine returns a suggestion
// (color does; radius is membership-only).
const driftLine = (v: { axis: string; found: string; expected?: string; expectedValue?: string }) =>
  `drift · ${v.axis} · found ${v.found}` + (v.expected ? ` → expected ${v.expected} ${v.expectedValue}` : '');

export function buildRun(inst: RunInstrument): Beat[] {
  const ref: ReferenceTokens = { color: inst.color, radius: inst.radius };
  const lg = pick(inst.radius, [/lg/], Object.keys(inst.radius).length - 1) || '8px';
  const driftCss = `.panel {
  background: ${DRIFT_COLORS.bg};
  color: ${DRIFT_COLORS.text};
  border: 1px solid ${DRIFT_COLORS.border};
  border-radius: ${lg};
}`;
  const driftView: PreviewState = { ...DRIFT_COLORS, radius: lg, css: driftCss, phase: 'drift' };
  const drift = checkDrift(ref, driftCss); // real — color drift, valid radius
  const clean = cleanPreview(inst);

  const beats: Beat[] = [
    { role: 'sys', text: `session — ${inst.name.toLowerCase()} · ${inst.id}`, pause: 520 },
    { role: 'tool', text: 'list_instruments → six systems on the floor', pause: 420 },
    { role: 'tool', text: `get_instrument ${inst.id} → ${inst.tokenTotal} tokens · ${inst.mode}`, pause: 620 },
    { role: 'agent', text: 'drafting a panel against the brief', pause: 880, preview: driftView },
    { role: 'tool', text: 'check_design_drift → measuring color + radius', pause: 540 },
  ];

  for (const v of drift.violations) {
    beats.push({ role: 'result', tone: 'drift', text: driftLine(v), pause: 300 });
  }

  beats.push(
    { role: 'result', tone: 'drift', text: `${drift.count} ${drift.count === 1 ? 'drift' : 'drifts'} from ${inst.name}`, pause: 720 },
    { role: 'agent', text: 'revising to honor the tokens', pause: 980, preview: clean },
    { role: 'tool', text: 'check_design_drift → re-measuring', pause: 560 },
    { role: 'verdict', tone: 'clean', text: `clean · honors ${inst.name}`, pause: 0 },
  );

  return beats;
}
