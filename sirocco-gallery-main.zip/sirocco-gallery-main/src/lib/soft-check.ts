// Shared client helper for the soft (intent) check. Used by the steward and the
// studio. Calls same-origin /api/intent (which calls Claude server-side).

export interface Soft {
  verdict: 'honors' | 'mixed' | 'strays';
  notes: string[];
}

export async function weighSpirit(
  instrumentId: string,
  code: string,
  hard: unknown,
): Promise<{ soft?: Soft; error?: string }> {
  try {
    const res = await fetch('/api/intent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ instrument_id: instrumentId, code, hard }),
    });
    const data = await res.json();
    if (!res.ok || data.error) return { error: data.error ?? 'spirit check failed' };
    return { soft: data.soft };
  } catch {
    return { error: 'network error' };
  }
}

const esc = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

export function renderSoft(r: { soft?: Soft; error?: string }): string {
  if (r.error || !r.soft) return `<div class="spirit error">— ${esc(r.error ?? 'no reading')}</div>`;
  const s = r.soft;
  const notes = s.notes.map((n) => `<li>${esc(n)}</li>`).join('');
  return `<div class="spirit v-${esc(s.verdict)}">
    <div class="spirit-head"><span class="spirit-label">the spirit</span><span class="spirit-verdict">${esc(s.verdict)}</span></div>
    <ul class="spirit-notes">${notes}</ul>
  </div>`;
}
