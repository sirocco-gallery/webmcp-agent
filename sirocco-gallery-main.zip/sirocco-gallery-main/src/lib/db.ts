// Persistence (Neon Postgres). Drives the BYO tier: a connector token resolves to
// a buyer's minted instrument. Also the commerce store (customers, entitlements,
// minted sets). No-ops gracefully when DATABASE_URL is unset (open tier only).
import { neon } from '@neondatabase/serverless';
import { createHash, randomBytes } from 'node:crypto';
import type { MintedInstrument } from './store';

const url = (import.meta.env.DATABASE_URL as string | undefined) ?? process.env.DATABASE_URL;
const sql = url ? neon(url) : null;
function db() {
  if (!sql) throw new Error('DATABASE_URL not set');
  return sql;
}

export const hashToken = (t: string) => createHash('sha256').update(t).digest('hex');

// Idempotent schema bootstrap — call from a setup step or the first write.
export async function initSchema(): Promise<void> {
  const q = db();
  await q`create table if not exists customers (
    id uuid primary key default gen_random_uuid(),
    email text unique not null,
    stripe_customer_id text,
    created_at timestamptz default now())`;
  await q`create table if not exists entitlements (
    id uuid primary key default gen_random_uuid(),
    customer_id uuid references customers(id) on delete cascade,
    kind text not null default 'byo_capability',
    status text not null default 'active',
    granted_at timestamptz default now())`;
  await q`create table if not exists minted_instruments (
    id uuid primary key default gen_random_uuid(),
    customer_id uuid references customers(id) on delete cascade unique,
    name text not null default 'my instrument',
    color jsonb not null default '{}'::jsonb,
    radius jsonb not null default '{}'::jsonb,
    updated_at timestamptz default now())`;
  await q`create table if not exists connector_tokens (
    id uuid primary key default gen_random_uuid(),
    customer_id uuid references customers(id) on delete cascade,
    token_hash text unique not null,
    created_at timestamptz default now(),
    revoked_at timestamptz)`;
}

export async function upsertCustomer(email: string, stripeCustomerId?: string): Promise<string> {
  const q = db();
  const rows = (await q`insert into customers (email, stripe_customer_id) values (${email.toLowerCase()}, ${stripeCustomerId ?? null})
    on conflict (email) do update set stripe_customer_id = coalesce(excluded.stripe_customer_id, customers.stripe_customer_id)
    returning id`) as { id: string }[];
  return rows[0].id;
}

export async function grantEntitlement(customerId: string): Promise<void> {
  const q = db();
  const existing = (await q`select id from entitlements where customer_id = ${customerId} and kind = 'byo_capability' and status = 'active' limit 1`) as { id: string }[];
  if (!existing.length) await q`insert into entitlements (customer_id) values (${customerId})`;
}

export async function entitledCustomerId(email: string): Promise<string | null> {
  const q = db();
  const rows = (await q`select c.id from customers c join entitlements e on e.customer_id = c.id
    where c.email = ${email.toLowerCase()} and e.status = 'active' limit 1`) as { id: string }[];
  return rows[0]?.id ?? null;
}

export async function saveMinted(customerId: string, name: string, color: Record<string, string>, radius: Record<string, string>): Promise<void> {
  const q = db();
  await q`insert into minted_instruments (customer_id, name, color, radius) values (${customerId}, ${name}, ${JSON.stringify(color)}, ${JSON.stringify(radius)})
    on conflict (customer_id) do update set name = excluded.name, color = excluded.color, radius = excluded.radius, updated_at = now()`;
}

export async function getMintedByCustomer(customerId: string): Promise<(MintedInstrument & { hasTokens: boolean }) | null> {
  const q = db();
  const rows = (await q`select name, color, radius from minted_instruments where customer_id = ${customerId} limit 1`) as MintedInstrument[];
  if (!rows.length) return null;
  const m = rows[0];
  return { ...m, hasTokens: Object.keys(m.color ?? {}).length > 0 };
}

// Issue a fresh connector token (revoking prior ones). Returns the RAW token —
// only its hash is stored, so it's shown once.
export async function issueToken(customerId: string): Promise<string> {
  const q = db();
  await q`update connector_tokens set revoked_at = now() where customer_id = ${customerId} and revoked_at is null`;
  const raw = randomBytes(24).toString('base64url');
  await q`insert into connector_tokens (customer_id, token_hash) values (${customerId}, ${hashToken(raw)})`;
  return raw;
}

export async function mintedInstrumentByToken(token: string): Promise<MintedInstrument | null> {
  if (!sql) return null;
  const rows = (await sql`select mi.name, mi.color, mi.radius from connector_tokens ct
    join minted_instruments mi on mi.customer_id = ct.customer_id
    where ct.token_hash = ${hashToken(token)} and ct.revoked_at is null limit 1`) as MintedInstrument[];
  return rows[0] ?? null;
}
