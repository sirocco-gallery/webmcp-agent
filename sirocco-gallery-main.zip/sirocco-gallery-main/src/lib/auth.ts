// Sessions + magic-links, no session store: a signed (HMAC) token in a cookie or
// a link. Needs SESSION_SECRET.
import { createHmac, timingSafeEqual } from 'node:crypto';

const secret = () => ((import.meta.env.SESSION_SECRET as string) ?? process.env.SESSION_SECRET ?? '');
const sign = (payload: string) => createHmac('sha256', secret()).update(payload).digest('base64url');

export function makeToken(data: Record<string, unknown>, ttlMs: number): string {
  const payload = Buffer.from(JSON.stringify({ ...data, exp: Date.now() + ttlMs })).toString('base64url');
  return `${payload}.${sign(payload)}`;
}

export function readToken<T = any>(token: string): T | null {
  const [payload, sig] = (token || '').split('.');
  if (!payload || !sig) return null;
  const expected = sign(payload);
  try {
    if (sig.length !== expected.length || !timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  } catch {
    return null;
  }
  let body: any;
  try {
    body = JSON.parse(Buffer.from(payload, 'base64url').toString());
  } catch {
    return null;
  }
  if (typeof body.exp === 'number' && Date.now() > body.exp) return null;
  return body as T;
}

const COOKIE = 'sirocco_session';
const DAY = 24 * 60 * 60;

export const sessionCookie = (email: string) =>
  `${COOKIE}=${makeToken({ email: email.toLowerCase() }, 30 * DAY * 1000)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${30 * DAY}`;

export function readSession(request: Request): { email: string } | null {
  const m = (request.headers.get('cookie') ?? '').match(new RegExp(`${COOKIE}=([^;]+)`));
  if (!m) return null;
  const data = readToken<{ email: string }>(m[1]);
  return data?.email ? { email: data.email } : null;
}
