// WebMCP provider surface for sirocco.
//
// This is the half the probes never touched: the page *offers* tools to an
// in-browser agent (Chrome 146+ Early Preview, flag-gated). Registration lives
// on document.modelContext per the W3C draft; we feature-detect and fall back to
// navigator.modelContext (what most write-ups show) and to a clean no-op when
// WebMCP is absent — so humans keep the in-page steward untouched.
//
// Tools execute in the browser context. The open surface runs the house palette
// (the demo substrate): check_design_drift is the deterministic checker run
// locally on the serialized reference tokens — no round-trip, and so no traffic
// to the review-frozen engine no matter how hard an agent walks the loop. The
// hosted engine stays reserved for the paid path.
//
// normalize_tokens is the first tool that acts on the agent's *own* tokens, not
// the curated catalog: a pure client-side transform (no network, no connector),
// so it's safe to offer freely and unaffected by the connector freeze.

import { normalize } from './normalize';
import { checkDrift, type ReferenceTokens } from './check';

export interface CatalogEntry {
  id: string;
  name: string;
  description: string;
  tags: string[];
  mode: string;
  palette: string[];
  tokens: number;
  enforced: number;
  formats: string[];
  price: string;
}

interface ToolResult {
  content: { type: 'text'; text: string }[];
}

interface WebMCPTool {
  name: string;
  description: string;
  inputSchema: Record<string, unknown>;
  execute: (args: Record<string, unknown>) => Promise<ToolResult>;
}

// Empirically (Canary), the surface lives on document.modelContext and
// navigator.modelContext is deprecated — and merely *reading* that getter logs a
// deprecation warning. So prefer document and only fall back to navigator if
// document can't register. No-op when WebMCP is absent so humans are unaffected.
const usable = (c: any) => c && (typeof c.registerTool === 'function' || typeof c.provideContext === 'function');
function modelContext(): any | null {
  const doc = typeof document !== 'undefined' ? (document as any).modelContext : null;
  if (usable(doc)) return doc;
  const nav = typeof navigator !== 'undefined' ? (navigator as any).modelContext : null;
  if (usable(nav)) return nav;
  return doc ?? nav ?? null;
}

const wrap = (value: unknown): ToolResult => ({
  content: [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }],
});

// Deterministic recommender — scores the catalog against a free-text need.
// Curated affinities per instrument (six fixed sets) plus a light/dark direction
// bias, so an obviously-light ask lands on the light-native instrument.
const AFFINITY: Record<string, string[]> = {
  '001': ['dark', 'console', 'dashboard', 'terminal', 'ledger', 'night', 'ink', 'oxblood', 'late', 'admin'],
  '002': ['warm', 'brass', 'gold', 'patina', 'lamplight', 'handheld', 'monochrome', 'vintage'],
  '003': ['light', 'minimal', 'minimalist', 'neutral', 'documentation', 'docs', 'doc', 'paper', 'clean', 'plaster', 'bright', 'airy', 'whitespace', 'editorial', 'reading'],
  '004': ['green', 'nature', 'forest', 'moss', 'conifer', 'botanical', 'garden', 'organic'],
  '005': ['red', 'ember', 'oxblood', 'amber', 'alert', 'critical', 'warning', 'press', 'heat'],
  '006': ['quiet', 'muted', 'calm', 'subtle', 'restrained', 'soft', 'understated', 'gentle'],
};

function recommend(catalog: CatalogEntry[], need: string) {
  const q = (need || '').toLowerCase();
  const words = q.split(/[^a-z]+/).filter((w) => w.length > 2);
  const wantsLight = /\b(light|bright|minimal|minimalist|paper|clean|doc|documentation|airy|editorial)\b/.test(q);
  const wantsDark = /\b(dark|night|console|terminal|dashboard|ledger|late|admin)\b/.test(q);
  const scored = catalog
    .map((e) => {
      const hay = `${e.tags.join(' ')} ${e.mode} ${e.description}`.toLowerCase();
      let score = words.reduce((n, w) => n + (hay.includes(w) ? 1 : 0), 0);
      score += (AFFINITY[e.id] ?? []).reduce((n, k) => n + (q.includes(k) ? 2 : 0), 0);
      const lightOnly = e.mode.includes('light') && !e.mode.includes('dark');
      const darkOnly = e.mode.includes('dark') && !e.mode.includes('light');
      if (wantsLight && !wantsDark) score += lightOnly ? 3 : e.mode.includes('light') ? 1 : 0;
      if (wantsDark && !wantsLight) score += darkOnly ? 3 : e.mode.includes('dark') ? 1 : 0;
      return { e, score };
    })
    .sort((a, b) => b.score - a.score);
  const top = scored[0];
  return {
    recommended: top.e.id,
    name: top.e.name,
    why: `closest match for “${need}” — ${top.e.tags.join(', ')} · ${top.e.mode}`,
    next: `call check_design_drift with instrument_id "${top.e.id}" and your CSS`,
    alternatives: scored.slice(1, 3).map((s) => ({ id: s.e.id, name: s.e.name })),
  };
}

export function buildTools(
  catalog: CatalogEntry[],
  references: Record<string, ReferenceTokens> = {},
): WebMCPTool[] {
  const find = (id: string) => catalog.find((c) => c.id === id);
  return [
    {
      name: 'list_instruments',
      description:
        'List the design instruments in the sirocco gallery. Each instrument is a curated, ' +
        'named design-token set (a palette) that ships with a live steward enforcing it.',
      inputSchema: { type: 'object', properties: {} },
      async execute() {
        return wrap(
          catalog.map((e) => ({
            id: e.id,
            name: e.name,
            tags: e.tags,
            mode: e.mode,
            palette: e.palette,
            tokens: e.tokens,
            price: e.price,
          })),
        );
      },
    },
    {
      name: 'recommend_instrument',
      description:
        'Recommend the instrument that best fits what you are building. Describe the mood, ' +
        'tone, and use case (e.g. “a dark warm dashboard” or “a light documentation site”).',
      inputSchema: {
        type: 'object',
        properties: {
          need: {
            type: 'string',
            description: 'What you are building and the mood/tone you want.',
            default: 'a dark warm dashboard',
            examples: ['a dark warm dashboard', 'a minimalist light documentation site'],
          },
        },
        required: ['need'],
      },
      async execute({ need }) {
        return wrap(recommend(catalog, String(need ?? '')));
      },
    },
    {
      name: 'get_instrument',
      description:
        'Get full details for one instrument by id: palette, token counts, export formats, ' +
        'and price. The full token files are delivered with purchase, not here.',
      inputSchema: {
        type: 'object',
        properties: { id: { type: 'string', description: 'Instrument id, e.g. "001".', default: '001', examples: ['001', '002', '003'] } },
        required: ['id'],
      },
      async execute({ id }) {
        const e = find(String(id ?? ''));
        return wrap(e ?? { error: `no instrument with id "${id}"` });
      },
    },
    {
      name: 'check_design_drift',
      description:
        'The steward. Check CSS against an instrument’s exact tokens (color + radius) and get ' +
        'every drift named: what you wrote versus what the instrument expects. Deterministic ' +
        'and local — runs in the page, no round-trip.',
      inputSchema: {
        type: 'object',
        properties: {
          instrument_id: { type: 'string', description: 'Instrument id, e.g. "001".', default: '001', examples: ['001', '002'] },
          code: {
            type: 'string',
            description: 'The CSS to check.',
            default: '.panel { color: #ff00ff; border-radius: 12px; }',
            examples: ['.panel { color: #ff00ff; border-radius: 12px; }'],
          },
        },
        required: ['instrument_id', 'code'],
      },
      async execute({ instrument_id, code }) {
        const id = String(instrument_id ?? '');
        const ref = references[id];
        if (!ref) return wrap({ error: `no instrument with id "${id}"` });
        const src = typeof code === 'string' ? code : '';
        if (!src.trim()) return wrap({ error: 'nothing to check — paste the CSS' });
        return wrap(checkDrift(ref, src));
      },
    },
    {
      name: 'normalize_tokens',
      description:
        'Mint a canonical token set from YOUR OWN design tokens — not the gallery’s. ' +
        'Paste a messy design system in any supported shape (CSS custom properties, a JSON / ' +
        'Tokens Studio file, a Tailwind theme/config, or just raw CSS to infer from) and get ' +
        'back sirocco’s canonical shape: color, radius, space, and font, plus the detected ' +
        'format and any warnings. Pure and local — nothing is sent to a server.',
      inputSchema: {
        type: 'object',
        properties: {
          tokens: {
            type: 'string',
            description:
              'Your design tokens as text: CSS custom properties, a JSON token set, a Tailwind ' +
              'theme object, or raw CSS to infer values from.',
            default: ':root { --color-bg: #0e0e10; --brand-500: #6e56cf; --radius-md: 8px; }',
            examples: [':root { --color-bg: #0e0e10; --brand-500: #6e56cf; --radius-md: 8px; }'],
          },
        },
        required: ['tokens'],
      },
      async execute({ tokens }) {
        const input = typeof tokens === 'string' ? tokens : '';
        if (!input.trim()) {
          return wrap({ error: 'nothing to normalize — paste your design tokens as text' });
        }
        return wrap(normalize(input));
      },
    },
  ];
}

export interface RegisterResult {
  ok: boolean;
  available: boolean; // is an in-browser agent runtime present?
  offered: number; // tools this page exposes
  count: number; // tools actually registered with the runtime
  reason?: string;
}

export async function registerWebMCP(
  catalog: CatalogEntry[],
  references: Record<string, ReferenceTokens> = {},
): Promise<RegisterResult> {
  const tools = buildTools(catalog, references);
  const offered = tools.length;
  const mc = modelContext();
  if (!mc) {
    return { ok: false, available: false, offered, count: 0, reason: 'no in-browser agent runtime' };
  }

  // Spec offers two shapes: provideContext({ tools }) registers the whole set in
  // one (idempotent) call; registerTool(tool) adds one. Prefer the batched call;
  // fall back per-tool. Single tool-descriptor argument — no extra options.
  if (typeof mc.provideContext === 'function') {
    try {
      await mc.provideContext({ tools });
      return { ok: true, available: true, offered, count: tools.length };
    } catch (err) {
      console.warn('[sirocco] WebMCP provideContext failed —', err);
      // fall through to per-tool registration
    }
  }

  if (typeof mc.registerTool !== 'function') {
    return { ok: false, available: true, offered, count: 0, reason: 'modelContext exposes neither provideContext nor registerTool' };
  }

  let count = 0;
  let lastErr = '';
  for (const tool of tools) {
    try {
      await mc.registerTool(tool);
      count += 1;
    } catch (err) {
      // Keep going — partial registration still works. The log tells us how the
      // draft has shifted if a tool is rejected.
      lastErr = (err as Error)?.message ?? String(err);
      console.warn('[sirocco] WebMCP registerTool failed on', tool.name, '—', err);
    }
  }
  return { ok: count > 0, available: true, offered, count, reason: count < offered ? lastErr : undefined };
}
