// Deterministic drift check — the open surface's stand-in for the hosted engine.
//
// Built to the engine's compact, already-public result contract so the two are
// swap-compatible (see runDriftCheck seam below): normalize hex first, compare by
// membership, and suggest the nearest token by squared-RGB distance, deduped.
// Hex literals only — functional colors (rgb()/hsl()/named) and var() references
// are intentionally left untouched, not interpreted. Pure and client-safe; no
// network. The hosted engine drops in behind the same contract, unchanged above.
//
// Match the engine, don't beat it: squared-RGB (not perceptual) nearest-token, so
// the open demo never over-represents what the live engine returns.

// Reference set. The hosted contract carries more axes (space/font/type); we send
// and enforce the two the engine enforces today: color + radius.
export interface ReferenceTokens {
  color: Record<string, string>;
  radius: Record<string, string>;
}

export interface Violation {
  axis: 'color' | 'radius';
  found: string;
  at: string;
  expected?: string;
  expectedValue?: string;
}

export interface HardResult {
  ok: boolean;
  count: number;
  violations: Violation[];
}

const HEX_G = /#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})\b/g; // scan
const HEX_1 = /^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/; // validate one

const normalizeHex = (v: string): string => {
  let h = v.replace(/^#/, '').toLowerCase();
  if (h.length === 3 || h.length === 4) h = h.split('').map((c) => c + c).join('');
  return '#' + h.slice(0, 6); // alpha dropped for matching
};

const rgb = (hex6: string): [number, number, number] => {
  const h = hex6.slice(1);
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
};

const lineOf = (code: string, idx: number) => code.slice(0, idx).split('\n').length;

function nearestToken(hex6: string, tokenColors: Record<string, string>) {
  const t = rgb(hex6);
  let best: { d: number; name: string; value: string } | null = null;
  for (const [name, val] of Object.entries(tokenColors)) {
    const s = val.trim();
    if (!HEX_1.test(s)) continue;
    const [r, g, b] = rgb(normalizeHex(s));
    const d = (r - t[0]) ** 2 + (g - t[1]) ** 2 + (b - t[2]) ** 2; // squared RGB Euclidean
    if (!best || d < best.d) best = { d, name, value: normalizeHex(s) };
  }
  return best;
}

function checkColor(code: string, tokenColors: Record<string, string>): Violation[] {
  const allowed = new Set(
    Object.values(tokenColors).filter((v) => HEX_1.test(v.trim())).map(normalizeHex),
  );
  const seen = new Set<string>();
  const out: Violation[] = [];
  for (const m of code.matchAll(HEX_G)) {
    const norm = normalizeHex(m[0]);
    if (allowed.has(norm) || seen.has(norm)) continue; // membership + dedup
    seen.add(norm);
    const near = nearestToken(norm, tokenColors);
    out.push({
      axis: 'color',
      found: norm,
      at: 'content:' + lineOf(code, m.index ?? 0),
      ...(near && { expected: 'color.' + near.name, expectedValue: near.value }),
    });
  }
  return out;
}

const DECL = /([a-zA-Z-]+)\s*:\s*([^;{}]+)/g;
const PX = /\b(\d+(?:\.\d+)?px)\b/;

function checkPx(
  code: string,
  tokens: Record<string, string>,
  axis: 'radius',
  propTest: (p: string) => boolean,
): Violation[] {
  const allowed = new Set(['0px', ...Object.values(tokens).map((v) => v.trim())]);
  const seen = new Set<string>();
  const out: Violation[] = [];
  for (const m of code.matchAll(DECL)) {
    const prop = m[1].toLowerCase().trim();
    if (!propTest(prop)) continue;
    const px = (m[2].match(PX) || [])[1];
    if (!px || allowed.has(px) || seen.has(px)) continue; // membership + dedup
    seen.add(px);
    out.push({ axis, found: px, at: 'content:' + lineOf(code, m.index ?? 0) });
  }
  return out;
}

// localDriftCheck — the stand-in. Same shape the connector returns.
export function checkDrift(ref: ReferenceTokens, code: string): HardResult {
  const violations = [
    ...checkColor(code, ref.color ?? {}),
    ...checkPx(code, ref.radius ?? {}, 'radius', (p) => p.includes('radius')),
  ];
  return { ok: violations.length === 0, count: violations.length, violations };
}

// The swap seam. Everything above this — WebMCP registration, the run loop, the
// result rendering — is written against this one contract. Post-review, the live
// hosted check drops in here returning the identical shape; nothing upstream
// changes. Today the open surface always uses the local stand-in (freeze-safe).
