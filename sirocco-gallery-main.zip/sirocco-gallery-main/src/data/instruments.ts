export type InstrumentStatus = 'OPEN';

export interface Instrument {
  id: string;
  number: string;
  name: string;
  status: InstrumentStatus;
  palette: [string, string, string];
  tags: string[];
  description: string;
  specs: { label: string; value: string }[];
  custody: string;
}

// The house instruments are the open demo substrate — free to walk, not for sale.
// (The paid path is BYO: the capability on your own tokens.)
const ACCESS = 'open';

export const instruments: Instrument[] = [
  {
    id: '001',
    number: '001',
    name: 'after hours',
    status: 'OPEN',
    palette: ['#0a0807', '#2a0d09', '#8b6a3a'],
    tags: ['duochrome', 'dark'],
    description:
      'A duochrome dark instrument. Ink and oxblood with a single brass accent. Built for late interfaces — dashboards, consoles, ledgers — where the screen is the room and the room is mostly off.',
    specs: [
      { label: 'steward', value: 'included · live' },
      { label: 'formats', value: 'css · scss · json · figma tokens' },
      { label: 'tokens', value: '23' },
      { label: 'mode', value: 'dark only' },
    ],
    custody: ACCESS,
  },
  {
    id: '002',
    number: '002',
    name: 'brass hour',
    status: 'OPEN',
    palette: ['#3d2a14', '#8b6a3a', '#d4a85a'],
    tags: ['monochrome', 'warm'],
    description:
      'A monochrome warm in three weights of brass. Reads as patina at low contrast, lamplight at high. For interfaces that want to feel handheld and slightly used.',
    specs: [
      { label: 'steward', value: 'included · live' },
      { label: 'formats', value: 'css · scss · json · figma tokens' },
      { label: 'tokens', value: '28' },
      { label: 'mode', value: 'dark · light' },
    ],
    custody: ACCESS,
  },
  {
    id: '003',
    number: '003',
    name: 'salt room',
    status: 'OPEN',
    palette: ['#ddd2bd', '#a89e8b', '#7a6f5e'],
    tags: ['neutral', 'light'],
    description:
      'A light neutral. Bone, dim bone, taupe. Whitespace as architecture. Reads as paper at distance and as plaster up close. For documents that want to be rooms.',
    specs: [
      { label: 'steward', value: 'included · live' },
      { label: 'formats', value: 'css · scss · json · figma tokens' },
      { label: 'tokens', value: '23' },
      { label: 'mode', value: 'light only' },
    ],
    custody: ACCESS,
  },
  {
    id: '004',
    number: '004',
    name: 'night garden',
    status: 'OPEN',
    palette: ['#0a0d0a', '#1f2e1c', '#3d4a2a'],
    tags: ['duochrome', 'dark'],
    description:
      'A duochrome dark in low greens. Conifer at midnight. Sits quieter than the warmer instruments and pairs well with mapping, telemetry, anything with a horizon.',
    specs: [
      { label: 'steward', value: 'included · live' },
      { label: 'formats', value: 'css · scss · json · figma tokens' },
      { label: 'tokens', value: '23' },
      { label: 'mode', value: 'dark only' },
    ],
    custody: ACCESS,
  },
  {
    id: '005',
    number: '005',
    name: 'second press',
    status: 'OPEN',
    palette: ['#1a0c08', '#5a2d18', '#a04a28'],
    tags: ['quadchrome', 'warm'],
    description:
      'A quadchrome warm — oxidized reds against a near-black ground. The widest range in the current catalog. Built for dense surfaces that need warmth without losing legibility.',
    specs: [
      { label: 'steward', value: 'included · live' },
      { label: 'formats', value: 'css · scss · json · figma tokens' },
      { label: 'tokens', value: '32' },
      { label: 'mode', value: 'dark · light' },
    ],
    custody: ACCESS,
  },
  {
    id: '006',
    number: '006',
    name: 'kept quiet',
    status: 'OPEN',
    palette: ['#1a1612', '#4a3f30', '#7a6f5e'],
    tags: ['duochrome', 'dark'],
    description:
      'A duochrome dark held at its quietest. Warm charcoal and taupe-brown under a muted brass that never raises its voice. For interfaces meant to recede — monitoring, long sessions, anything lived in rather than looked at.',
    specs: [
      { label: 'steward', value: 'included · live' },
      { label: 'formats', value: 'css · scss · json · figma tokens' },
      { label: 'tokens', value: '28' },
      { label: 'mode', value: 'dark · light' },
    ],
    custody: ACCESS,
  },
];

export function getInstrument(id: string): Instrument | undefined {
  return instruments.find((i) => i.id === id);
}
