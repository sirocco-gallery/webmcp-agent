import type { TokenSet } from './types';
import { afterHours } from './after-hours';
import { brassHour } from './brass-hour';
import { saltRoom } from './salt-room';
import { nightGarden } from './night-garden';
import { secondPress } from './second-press';
import { keptQuiet } from './kept-quiet';

export const tokenSets: Record<string, TokenSet> = {
  '001': afterHours,
  '002': brassHour,
  '003': saltRoom,
  '004': nightGarden,
  '005': secondPress,
  '006': keptQuiet,
};

export function getTokenSet(id: string): TokenSet | undefined {
  return tokenSets[id];
}

export function hasTokenSet(id: string): boolean {
  return id in tokenSets;
}

/**
 * Reference tokens for the swatchdog hard check. Only the axes swatchdog
 * enforces today (color + radius) are sent; space/font are authored for the
 * export formats but the connector skips them, so we don't pay to send them.
 */
export function getReferenceTokens(
  id: string,
): { color: Record<string, string>; radius: Record<string, string> } | undefined {
  const t = tokenSets[id];
  if (!t) return undefined;
  return { color: t.color, radius: t.radius };
}

/**
 * total    — every token a custodian receives (all four axes).
 * enforced — the count swatchdog actually checks (color + radius).
 */
export function getTokenCounts(id: string): { total: number; enforced: number } | undefined {
  const t = tokenSets[id];
  if (!t) return undefined;
  const n = (o: Record<string, string>) => Object.keys(o).length;
  const enforced = n(t.color) + n(t.radius);
  const total = enforced + n(t.space) + n(t.font);
  return { total, enforced };
}

export type { TokenSet };
