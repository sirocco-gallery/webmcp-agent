import type { TokenSet } from './types';

// Instrument 002 — brass hour
// Monochrome warm in three weights of brass. Ships light + dark.
// Patina at low contrast, lamplight at high.
export const brassHour: TokenSet = {
  id: '002',
  name: 'brass hour',
  intent:
    'A monochrome warm in three weights of brass. Reads as patina at low contrast, ' +
    'lamplight at high. For interfaces that want to feel handheld and slightly used. ' +
    'Ships light and dark.',
  color: {
    // dark mode
    'bg.base': '#14100a', // warm near-black ground
    'bg.surface': '#1f1810', // raised panels
    'bg.umber': '#3d2a14', // deep brass — wells, active
    'text.primary': '#e8d8b8', // warm bone
    'text.secondary': '#b89a6a',
    'text.muted': '#8b6a3a', // brass — labels, meta
    accent: '#d4a85a', // lamplight — the high weight
    'accent.hover': '#e4bd78',
    'border.subtle': '#29200f',
    'border.brass': '#4a3a1f',
    // light mode
    'bg.base.light': '#f2e7d2', // warm paper
    'bg.surface.light': '#e8d8bb',
    'text.primary.light': '#3d2a14', // deep brass on paper
    'text.secondary.light': '#6b4f2a',
    'border.light': '#d8c39a',
  },
  radius: { sm: '3px', md: '6px', lg: '10px' },
  space: { xs: '4px', sm: '8px', md: '16px', lg: '24px', xl: '40px' },
  font: {
    'family.display': "'Cormorant Garamond', serif",
    'family.mono': "'JetBrains Mono', ui-monospace, monospace",
    'size.micro': '10.5px',
    'size.body': '15px',
    'size.display': '48px',
  },
};
