import type { TokenSet } from './types';

// Instrument 004 — night garden
// Duochrome dark in low greens. Conifer at midnight. Dark only.
export const nightGarden: TokenSet = {
  id: '004',
  name: 'night garden',
  intent:
    'A duochrome dark in low greens. Conifer at midnight. Sits quieter than the warmer ' +
    'instruments and pairs well with mapping, telemetry, anything with a horizon. Dark only.',
  color: {
    'bg.base': '#0a0d0a', // near-black green ground
    'bg.surface': '#121711', // raised panels
    'bg.conifer': '#1f2e1c', // second chroma — wells, active
    'text.primary': '#d8e0cd', // pale green-bone
    'text.secondary': '#9aa890',
    'text.muted': '#6b7560', // muted green — labels, meta
    accent: '#8aa05a', // lichen — the single accent, legible on near-black
    'accent.hover': '#9cb36a',
    'border.subtle': '#182115',
    'border.moss': '#2f3d24',
  },
  radius: { sm: '2px', md: '4px', lg: '8px' },
  space: { xs: '4px', sm: '8px', md: '16px', lg: '24px', xl: '40px' },
  font: {
    'family.display': "'Cormorant Garamond', serif",
    'family.mono': "'JetBrains Mono', ui-monospace, monospace",
    'size.micro': '10.5px',
    'size.body': '15px',
    'size.display': '48px',
  },
};
