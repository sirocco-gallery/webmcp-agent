import type { TokenSet } from './types';

// Instrument 003 — salt room
// A light neutral. Bone, dim bone, taupe. Whitespace as architecture.
// Paper at distance, plaster up close. Light only.
export const saltRoom: TokenSet = {
  id: '003',
  name: 'salt room',
  intent:
    'A light neutral. Bone, dim bone, taupe. Whitespace as architecture. Reads as paper ' +
    'at distance and as plaster up close. For documents that want to be rooms. Light only.',
  color: {
    'bg.base': '#ece3d2', // paper ground
    'bg.surface': '#f4ecdc', // raised — the lightest plane
    'bg.sink': '#ddd2bd', // bone — recessed wells
    'text.primary': '#2e2a22', // warm near-black ink
    'text.secondary': '#5a5142',
    'text.muted': '#7a6f5e', // taupe — labels, meta
    accent: '#8b6a3a', // brass — the house accent, legible on light
    'accent.hover': '#6f5328', // brass deepened for hover on light
    'border.subtle': '#cfc3ab',
    'border.strong': '#a89e8b', // dim bone
  },
  radius: { sm: '4px', md: '8px', lg: '12px' },
  space: { xs: '4px', sm: '8px', md: '16px', lg: '24px', xl: '40px' },
  font: {
    'family.display': "'Cormorant Garamond', serif",
    'family.mono': "'JetBrains Mono', ui-monospace, monospace",
    'size.micro': '10.5px',
    'size.body': '15px',
    'size.display': '48px',
  },
};
