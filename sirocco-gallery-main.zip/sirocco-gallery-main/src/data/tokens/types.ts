// Canonical token-set shape for sirocco instruments.
// One source of truth → drives the 4 export formats AND the swatchdog reference set.
export interface TokenSet {
  id: string;
  name: string;
  /** Design intent — the prose the soft-check layer will reason against (Phase 3). */
  intent: string;
  /** Hex values only, so the swatchdog hard check (which matches hex) can enforce them. */
  color: Record<string, string>;
  radius: Record<string, string>;
  space: Record<string, string>;
  font: Record<string, string>;
}
