import type { TokenSet } from './types';

// Instrument 005 — second press
// Quadchrome warm — oxidized reds against a near-black ground. The widest range
// in the catalog: a four-chroma color story, a semantic state layer, and light + dark.
export const secondPress: TokenSet = {
  id: '005',
  name: 'second press',
  intent:
    'A quadchrome warm — oxidized reds against a near-black ground. The widest range in ' +
    'the current catalog. Built for dense surfaces that need warmth without losing ' +
    'legibility. Carries a semantic state layer and ships light and dark.',
  color: {
    // dark mode — four warm chromas
    'bg.base': '#160a06', // near-black ground
    'bg.surface': '#22100a', // raised panels
    'bg.ember': '#5a2d18', // deep oxide — wells, active
    'text.primary': '#ecd8c8', // warm bone
    'text.secondary': '#c79a82',
    'text.muted': '#9a6a52',
    accent: '#a04a28', // terracotta — the primary accent
    'accent.hover': '#c25c34',
    'accent.amber': '#c9743f', // the fourth chroma — ember highlight
    'border.subtle': '#2a140d',
    'border.ember': '#4a2414',
    // semantic state layer (warm-tuned, distinct from the accents)
    'state.positive': '#7a8f3f', // olive
    'state.caution': '#c9913f', // amber
    'state.critical': '#b03b28', // warm red
    // light mode
    'bg.base.light': '#f4e7da',
    'bg.surface.light': '#ead7c6',
    'text.primary.light': '#1a0c08',
    'text.secondary.light': '#5a2d18',
    'border.light': '#d8bfa8',
  },
  radius: { sm: '3px', md: '6px', lg: '10px' },
  space: { xs: '4px', sm: '8px', md: '16px', lg: '24px', xl: '40px' },
  font: {
    'family.display': "'Cormorant Garamond', serif",
    'family.mono': "'JetBrains Mono', ui-monospace, monospace",
    'size.micro': '10.5px',
    'size.body': '15px',
    'size.display': '48px',
  },
};
