import type { TokenSet } from './types';

// Instrument 001 — after hours
// Duochrome dark. Ink and oxblood with a single brass accent.
// All colors are solid hex (not rgba) so swatchdog can enforce them.
export const afterHours: TokenSet = {
  id: '001',
  name: 'after hours',
  intent:
    'A duochrome dark instrument. Ink and oxblood with a single brass accent. ' +
    'Built for late interfaces — dashboards, consoles, ledgers — where the screen ' +
    'is the room and the room is mostly off.',
  color: {
    'bg.base': '#0a0807', // the ground — screen mostly off
    'bg.surface': '#140b09', // raised panels, cards (one step of elevation above ink)
    'bg.oxblood': '#2a0d09', // second chroma — wells, active states
    'text.primary': '#ddd2bd', // bone — primary text
    'text.secondary': '#a89e8b', // dim bone — secondary text
    'text.muted': '#7a6f5e', // taupe — labels, meta
    accent: '#8b6a3a', // brass — the single accent
    'accent.hover': '#a8824a', // brass, lifted (interaction)
    'border.subtle': '#211a14', // hairline dividers
    'border.brass': '#3a2c18', // accent borders
  },
  radius: {
    sm: '2px',
    md: '4px',
    lg: '8px',
  },
  space: {
    xs: '4px',
    sm: '8px',
    md: '16px',
    lg: '24px',
    xl: '40px',
  },
  font: {
    'family.display': "'Cormorant Garamond', serif",
    'family.mono': "'JetBrains Mono', ui-monospace, monospace",
    'size.micro': '10.5px',
    'size.body': '15px',
    'size.display': '48px',
  },
};
