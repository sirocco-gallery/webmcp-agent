import type { TokenSet } from './types';

// Instrument 006 — kept quiet
// A duochrome dark held at its quietest. Muted brass restraint. Ships light + dark.
export const keptQuiet: TokenSet = {
  id: '006',
  name: 'kept quiet',
  intent:
    'A duochrome dark held at its quietest. Warm charcoal and taupe-brown under a muted ' +
    'brass that never raises its voice. For interfaces meant to recede — monitoring, long ' +
    'sessions, anything lived in rather than looked at. Ships light and dark.',
  color: {
    // dark mode
    'bg.base': '#16130f', // warm charcoal ground
    'bg.surface': '#1f1b15', // raised panels
    'bg.sink': '#4a3f30', // taupe-brown — wells, active
    'text.primary': '#ddd2bd', // bone
    'text.secondary': '#a89e8b',
    'text.muted': '#7a6f5e', // taupe — labels, meta
    accent: '#8b7a5a', // muted brass — quieter than the house brass
    'accent.hover': '#9d8c6a',
    'border.subtle': '#221d16',
    'border.muted': '#3a3226',
    // light mode
    'bg.base.light': '#e8e2d4',
    'bg.surface.light': '#f0ebdf',
    'text.primary.light': '#1a1612',
    'text.secondary.light': '#4a3f30',
    'border.light': '#d0c7b4',
  },
  radius: { sm: '4px', md: '8px', lg: '12px' },
  space: { xs: '4px', sm: '8px', md: '16px', lg: '24px', xl: '40px' },
  font: {
    'family.display': "'Cormorant Garamond', serif",
    'family.mono': "'JetBrains Mono', ui-monospace, monospace",
    'size.micro': '10.5px',
    'size.body': '15px',
    'size.display': '48px',
  },
};
