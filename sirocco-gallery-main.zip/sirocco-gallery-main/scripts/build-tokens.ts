// Generates the four downloadable export formats from the canonical token sets.
//   private/tokens/<id>/tokens.css · tokens.scss · tokens.json · <slug>.tokens.json
//
// Output lives OUTSIDE public/ on purpose: the token files are part of the paid
// bundle, staged for gated delivery, never served. The steward reads tokens from
// src/data/tokens, not these files. Run: npm run tokens
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { tokenSets } from '../src/data/tokens/index.ts';
import { toCss, toScss, toJson, toFigma, slug } from '../src/lib/token-export.ts';

const root = resolve(import.meta.dirname, '..');
for (const t of Object.values(tokenSets)) {
  const dir = resolve(root, 'private', 'tokens', t.id);
  mkdirSync(dir, { recursive: true });
  writeFileSync(resolve(dir, 'tokens.css'), toCss(t));
  writeFileSync(resolve(dir, 'tokens.scss'), toScss(t));
  writeFileSync(resolve(dir, 'tokens.json'), toJson(t) + '\n');
  writeFileSync(resolve(dir, `${slug(t.name)}.tokens.json`), toFigma(t) + '\n');
  console.log(`✓ ${t.id} ${t.name} → private/tokens/${t.id}/ (css · scss · json · figma)`);
}
